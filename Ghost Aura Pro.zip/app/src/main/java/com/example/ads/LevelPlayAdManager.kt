package com.example.ads

import android.app.Activity
import android.util.Log
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.unity3d.mediation.LevelPlay
import com.unity3d.mediation.LevelPlayAdError
import com.unity3d.mediation.LevelPlayAdInfo
import com.unity3d.mediation.LevelPlayAdSize
import com.unity3d.mediation.LevelPlayConfiguration
import com.unity3d.mediation.LevelPlayInitError
import com.unity3d.mediation.LevelPlayInitListener
import com.unity3d.mediation.LevelPlayInitRequest
import com.unity3d.mediation.banner.LevelPlayBannerAdView
import com.unity3d.mediation.banner.LevelPlayBannerAdViewListener
import com.unity3d.mediation.interstitial.LevelPlayInterstitialAd
import com.unity3d.mediation.interstitial.LevelPlayInterstitialAdListener
import com.unity3d.mediation.rewarded.LevelPlayReward
import com.unity3d.mediation.rewarded.LevelPlayRewardedAd
import com.unity3d.mediation.rewarded.LevelPlayRewardedAdListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Thin wrapper around Unity LevelPlay SDK (init + interstitial + rewarded + banner). */
object LevelPlayAdManager {
    private const val TAG = "LevelPlayAds"

    private val _sdkReady = MutableStateFlow(false)
    /** true once LevelPlay.init succeeded (banner composable waits for this). */
    val sdkReady: StateFlow<Boolean> = _sdkReady

    private var initStarted = false
    private var interstitial: LevelPlayInterstitialAd? = null
    private var rewarded: LevelPlayRewardedAd? = null

    private var actionCount = 0
    private var lastInterstitialShownAt = 0L
    private var pendingRewardCallback: (() -> Unit)? = null

    fun init(activity: Activity) {
        if (initStarted) return
        if (!AdConfig.isConfigured()) {
            Log.w(TAG, "Ads disabled: fill AdConfig.kt with your App Key and Ad Unit IDs.")
            return
        }
        initStarted = true

        val request = LevelPlayInitRequest.Builder(AdConfig.APP_KEY).build()
        LevelPlay.init(activity.applicationContext, request, object : LevelPlayInitListener {
            override fun onInitSuccess(configuration: LevelPlayConfiguration) {
                Log.d(TAG, "LevelPlay init success")
                createInterstitial()
                createRewarded()
                _sdkReady.value = true
            }

            override fun onInitFailed(error: LevelPlayInitError) {
                Log.e(TAG, "LevelPlay init failed: ${error.errorMessage}")
                initStarted = false // allow retry on next init() call
            }
        })
    }

    // ---------------- Interstitial ----------------

    private fun createInterstitial() {
        val ad = LevelPlayInterstitialAd(AdConfig.INTERSTITIAL_AD_UNIT_ID)
        ad.setListener(object : LevelPlayInterstitialAdListener {
            override fun onAdLoaded(adInfo: LevelPlayAdInfo) { Log.d(TAG, "Interstitial loaded") }
            override fun onAdLoadFailed(error: LevelPlayAdError) {
                Log.e(TAG, "Interstitial load failed: ${error.errorMessage}")
            }
            override fun onAdInfoChanged(adInfo: LevelPlayAdInfo) {}
            override fun onAdDisplayed(adInfo: LevelPlayAdInfo) {}
            override fun onAdDisplayFailed(error: LevelPlayAdError, adInfo: LevelPlayAdInfo) {
                Log.e(TAG, "Interstitial display failed: ${error.errorMessage}")
                ad.loadAd()
            }
            override fun onAdClicked(adInfo: LevelPlayAdInfo) {}
            override fun onAdClosed(adInfo: LevelPlayAdInfo) { ad.loadAd() } // preload next
        })
        interstitial = ad
        ad.loadAd()
    }

    /** Call on a natural transition (e.g. tab switch). Shows an interstitial only when paced. */
    fun onNaturalTransition(activity: Activity) {
        actionCount++
        if (actionCount % AdConfig.INTERSTITIAL_EVERY_N_ACTIONS != 0) return
        val now = System.currentTimeMillis()
        if (now - lastInterstitialShownAt < AdConfig.INTERSTITIAL_MIN_INTERVAL_MS) return
        if (showInterstitial(activity)) lastInterstitialShownAt = now
    }

    fun showInterstitial(activity: Activity): Boolean {
        val ad = interstitial ?: return false
        val placement = AdConfig.PLACEMENT_INTERSTITIAL
        if (ad.isAdReady() && !LevelPlayInterstitialAd.isPlacementCapped(placement)) {
            ad.showAd(activity, placement)
            return true
        }
        return false
    }

    // ---------------- Rewarded ----------------

    private fun createRewarded() {
        val ad = LevelPlayRewardedAd(AdConfig.REWARDED_AD_UNIT_ID)
        ad.setListener(object : LevelPlayRewardedAdListener {
            override fun onAdLoaded(adInfo: LevelPlayAdInfo) { Log.d(TAG, "Rewarded loaded") }
            override fun onAdLoadFailed(error: LevelPlayAdError) {
                Log.e(TAG, "Rewarded load failed: ${error.errorMessage}")
            }
            override fun onAdInfoChanged(adInfo: LevelPlayAdInfo) {}
            override fun onAdDisplayed(adInfo: LevelPlayAdInfo) {}
            override fun onAdDisplayFailed(error: LevelPlayAdError, adInfo: LevelPlayAdInfo) {
                Log.e(TAG, "Rewarded display failed: ${error.errorMessage}")
                pendingRewardCallback = null
                ad.loadAd()
            }
            override fun onAdClicked(adInfo: LevelPlayAdInfo) {}
            override fun onAdRewarded(reward: LevelPlayReward, adInfo: LevelPlayAdInfo) {
                pendingRewardCallback?.invoke()
                pendingRewardCallback = null
            }
            override fun onAdClosed(adInfo: LevelPlayAdInfo) { ad.loadAd() }
        })
        rewarded = ad
        ad.loadAd()
    }

    fun isRewardedReady(): Boolean = rewarded?.isAdReady() == true

    /** Shows a rewarded ad; [onReward] runs only if the user completes it. Returns false if not ready. */
    fun showRewarded(activity: Activity, onReward: () -> Unit): Boolean {
        val ad = rewarded ?: return false
        val placement = AdConfig.PLACEMENT_REWARDED
        if (ad.isAdReady() && !LevelPlayRewardedAd.isPlacementCapped(placement)) {
            pendingRewardCallback = onReward
            ad.showAd(activity, placement)
            return true
        }
        return false
    }

    // ---------------- Banner ----------------

    fun createBanner(activity: Activity): LevelPlayBannerAdView {
        val config = LevelPlayBannerAdView.Config.Builder()
            .setAdSize(LevelPlayAdSize.BANNER)
            .setPlacementName(AdConfig.PLACEMENT_BANNER)
            .build()
        val banner = LevelPlayBannerAdView(activity, AdConfig.BANNER_AD_UNIT_ID, config)
        banner.setBannerListener(object : LevelPlayBannerAdViewListener {
            override fun onAdLoaded(adInfo: LevelPlayAdInfo) { Log.d(TAG, "Banner loaded") }
            override fun onAdLoadFailed(error: LevelPlayAdError) {
                Log.e(TAG, "Banner load failed: ${error.errorMessage}")
            }
            override fun onAdDisplayed(adInfo: LevelPlayAdInfo) {}
            override fun onAdDisplayFailed(adInfo: LevelPlayAdInfo, error: LevelPlayAdError) {}
            override fun onAdClicked(adInfo: LevelPlayAdInfo) {}
            override fun onAdExpanded(adInfo: LevelPlayAdInfo) {}
            override fun onAdCollapsed(adInfo: LevelPlayAdInfo) {}
            override fun onAdLeftApplication(adInfo: LevelPlayAdInfo) {}
        })
        banner.loadAd()
        return banner
    }
}

/** Compose banner slot. Renders nothing until LevelPlay is initialized. */
@Composable
fun LevelPlayBannerSlot(modifier: Modifier = Modifier) {
    val ready by LevelPlayAdManager.sdkReady.collectAsStateWithLifecycle()
    if (!ready) return
    val activity = LocalContext.current as? Activity ?: return

    val banner = remember(activity) { LevelPlayAdManager.createBanner(activity) }
    DisposableEffect(banner) { onDispose { banner.destroy() } }

    Box(
        modifier = modifier.fillMaxWidth().height(50.dp),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(factory = { banner })
    }
}
