package com.example.ads

/**
 * Unity LevelPlay configuration.
 *
 * ⚠️ Replace the 4 "YOUR_..." values below from the LevelPlay dashboard:
 *  - App Key:      LevelPlay → Setup → Apps → your app → "App Key"
 *  - Ad Unit IDs:  LevelPlay → Setup → Ad units (Banner / Interstitial / Rewarded)
 *
 * Placement names are already filled in from your dashboard screenshot.
 * While a value still starts with "YOUR_", ads stay off and the app runs normally.
 */
object AdConfig {
    const val APP_KEY = "YOUR_LEVELPLAY_APP_KEY"

    const val BANNER_AD_UNIT_ID = "YOUR_BANNER_AD_UNIT_ID"
    const val INTERSTITIAL_AD_UNIT_ID = "YOUR_INTERSTITIAL_AD_UNIT_ID"
    const val REWARDED_AD_UNIT_ID = "YOUR_REWARDED_AD_UNIT_ID"

    // Placement names (from your dashboard)
    const val PLACEMENT_BANNER = "BP_Banner_Android"
    const val PLACEMENT_INTERSTITIAL = "BP_Interstitial_Android"
    const val PLACEMENT_REWARDED = "BP_Rewarded_Android"

    // Interstitial pacing: show after N tab switches, and never more often than every X ms
    const val INTERSTITIAL_EVERY_N_ACTIONS = 5
    const val INTERSTITIAL_MIN_INTERVAL_MS = 60_000L

    fun isConfigured(): Boolean =
        listOf(APP_KEY, BANNER_AD_UNIT_ID, INTERSTITIAL_AD_UNIT_ID, REWARDED_AD_UNIT_ID)
            .none { it.isBlank() || it.startsWith("YOUR_") }
}
