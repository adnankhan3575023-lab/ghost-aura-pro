package com.example.monitoring

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.view.Choreographer
import android.view.WindowManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class TelemetrySnapshot(
    val timestampMs: Long = System.currentTimeMillis(),
    // RAM
    val ramTotalMb: Long = 0L,
    val ramAvailableMb: Long = 0L,
    val ramUsedMb: Long = 0L,
    val ramUsagePercent: Float = 0f,
    val isLowMemory: Boolean = false,
    // Battery
    val batteryPercent: Int? = null,
    val batteryTempCelsius: Float? = null, // null -> "Not supported"
    val batteryVoltageMv: Int? = null,
    val isCharging: Boolean = false,
    val batteryHealthLabel: String = "Unknown",
    // Storage
    val storageTotalGb: Float = 0f,
    val storageAvailableGb: Float = 0f,
    val storageUsedGb: Float = 0f,
    val storageUsagePercent: Float = 0f,
    // Display & Frame Pacing
    val resolutionLabel: String = "Unknown",
    val densityDpi: Int = 0,
    val displayRefreshRateHz: Float? = null,
    val supportedRefreshRatesHz: List<Int> = emptyList(),
    val localUiFramePacingFps: Float = 60f,
    val externalGameFpsStatus: String = "Not supported (Android OS Sandbox)",
    // Thermal
    val thermalStatusLabel: String = "Not supported",
    val thermalSeverityLevel: Int = 0, // 0 = nominal/unsupported, 1 = light, 2 = moderate, 3+ = severe
    // Network
    val networkConnected: Boolean = false,
    val networkTransportLabel: String = "Offline",
    val networkDownstreamKbps: Int? = null,
    // Device Identity
    val deviceManufacturerModel: String = "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}",
    val androidVersionLabel: String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
    val cpuAbi: String = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a",
    val cpuCores: Int = Runtime.getRuntime().availableProcessors()
)

data class ReadinessCheckItem(
    val title: String,
    val currentValue: String,
    val status: ReadinessLevel, // OPTIMAL, CAUTION, ATTENTION, UNSUPPORTED
    val recommendation: String
)

enum class ReadinessLevel(val label: String) {
    OPTIMAL("READY"),
    CAUTION("MODERATE"),
    ATTENTION("CHECK"),
    UNSUPPORTED("N/A")
}

data class LatencyTestResult(
    val endpoint: String,
    val success: Boolean,
    val samplesMs: List<Long> = emptyList(),
    val minMs: Long = 0L,
    val avgMs: Long = 0L,
    val maxMs: Long = 0L,
    val jitterMs: Long = 0L,
    val errorMessage: String? = null,
    val timestampMs: Long = System.currentTimeMillis()
)

data class AppIntegrityReport(
    val packageName: String,
    val versionName: String,
    val signatureSha256: String,
    val installerSource: String,
    val isDebugBuild: Boolean,
    val overlayPermissionGranted: Boolean,
    val networkStateGranted: Boolean,
    val vibrateGranted: Boolean
)

class DeviceTelemetryMonitor(private val context: Context) {

    @Volatile
    private var measuredUiFps: Float = 60f
    private var frameCount = 0
    private var lastFrameSampleNs = 0L
    private var choreographerActive = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!choreographerActive) return
            if (lastFrameSampleNs == 0L) {
                lastFrameSampleNs = frameTimeNanos
            }
            frameCount++
            val elapsedNs = frameTimeNanos - lastFrameSampleNs
            if (elapsedNs >= 500_000_000L) { // update every 0.5s
                val fps = (frameCount * 1_000_000_000f) / elapsedNs
                measuredUiFps = fps.coerceIn(1f, 240f)
                frameCount = 0
                lastFrameSampleNs = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun startUiFramePacingObserver() {
        if (!choreographerActive) {
            choreographerActive = true
            lastFrameSampleNs = 0L
            frameCount = 0
            runCatching {
                Choreographer.getInstance().postFrameCallback(frameCallback)
            }
        }
    }

    fun stopUiFramePacingObserver() {
        choreographerActive = false
        runCatching {
            Choreographer.getInstance().removeFrameCallback(frameCallback)
        }
    }

    fun sampleSnapshot(): TelemetrySnapshot {
        // 1. RAM
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memInfo)
        val totalRamMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(1L)
        val availRamMb = (memInfo.availMem / (1024L * 1024L)).coerceAtLeast(0L)
        val usedRamMb = (totalRamMb - availRamMb).coerceAtLeast(0L)
        val ramPercent = ((usedRamMb.toFloat() / totalRamMb.toFloat()) * 100f).coerceIn(0f, 100f)

        // 2. Battery
        val batteryIntent = runCatching {
            context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull()

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) ((level * 100f) / scale).roundToInt() else null

        val rawTempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val batteryTempC = if (rawTempTenths != Int.MIN_VALUE && rawTempTenths in -200..1000) {
            rawTempTenths / 10f
        } else {
            null
        }

        val rawVoltage = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val voltageMv = if (rawVoltage > 0) rawVoltage else null

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val health = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val healthLabel = when (health) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Depleted"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over-Voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Not supported"
        }

        // 3. Internal Storage
        val statFs = runCatching { StatFs(Environment.getDataDirectory().path) }.getOrNull()
        val totalBytes = statFs?.totalBytes ?: 0L
        val availBytes = statFs?.availableBytes ?: 0L
        val usedBytes = (totalBytes - availBytes).coerceAtLeast(0L)
        val gbDiv = 1024f * 1024f * 1024f
        val totalGb = totalBytes / gbDiv
        val availGb = availBytes / gbDiv
        val usedGb = usedBytes / gbDiv
        val storagePct = if (totalBytes > 0L) ((usedBytes.toFloat() / totalBytes.toFloat()) * 100f).coerceIn(0f, 100f) else 0f

        // 4. Display Resolution & Refresh Rate
        val metrics = context.resources.displayMetrics
        val widthPx = metrics.widthPixels
        val heightPx = metrics.heightPixels
        val dpi = metrics.densityDpi

        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
        @Suppress("DEPRECATION")
        val display = windowManager?.defaultDisplay
        val refreshHz = display?.refreshRate?.takeIf { it > 0f }
        val supportedRates = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            display?.supportedModes?.map { it.refreshRate.roundToInt() }?.distinct()?.sorted() ?: emptyList()
        } else {
            listOfNotNull(refreshHz?.roundToInt())
        }

        // 5. Thermal Status
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        var thermalLabel = "Not supported"
        var thermalSeverity = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
            val tStatus = runCatching { powerManager.currentThermalStatus }.getOrDefault(-1)
            when (tStatus) {
                PowerManager.THERMAL_STATUS_NONE -> {
                    thermalLabel = "Nominal (Cool)"
                    thermalSeverity = 0
                }
                PowerManager.THERMAL_STATUS_LIGHT -> {
                    thermalLabel = "Light Warmth"
                    thermalSeverity = 1
                }
                PowerManager.THERMAL_STATUS_MODERATE -> {
                    thermalLabel = "Moderate Warmth"
                    thermalSeverity = 2
                }
                PowerManager.THERMAL_STATUS_SEVERE -> {
                    thermalLabel = "Severe Throttling Risk"
                    thermalSeverity = 3
                }
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> {
                    thermalLabel = "Critical Thermal State"
                    thermalSeverity = 4
                }
                else -> {
                    thermalLabel = "Not supported"
                    thermalSeverity = 0
                }
            }
        }

        // 6. Network Status
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        var netConnected = false
        var transportLabel = "Disconnected"
        var downKbps: Int? = null
        if (connectivityManager != null) {
            val activeNet = connectivityManager.activeNetwork
            val caps = if (activeNet != null) connectivityManager.getNetworkCapabilities(activeNet) else null
            if (caps != null) {
                netConnected = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                transportLabel = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular Data"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet LAN"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN Tunnel"
                    else -> "Active Network"
                }
                val bw = caps.linkDownstreamBandwidthKbps
                if (bw > 0) downKbps = bw
            }
        }

        return TelemetrySnapshot(
            timestampMs = System.currentTimeMillis(),
            ramTotalMb = totalRamMb,
            ramAvailableMb = availRamMb,
            ramUsedMb = usedRamMb,
            ramUsagePercent = ramPercent,
            isLowMemory = memInfo.lowMemory,
            batteryPercent = batteryPct,
            batteryTempCelsius = batteryTempC,
            batteryVoltageMv = voltageMv,
            isCharging = isCharging,
            batteryHealthLabel = healthLabel,
            storageTotalGb = totalGb,
            storageAvailableGb = availGb,
            storageUsedGb = usedGb,
            storageUsagePercent = storagePct,
            resolutionLabel = "${widthPx} × ${heightPx} px",
            densityDpi = dpi,
            displayRefreshRateHz = refreshHz,
            supportedRefreshRatesHz = supportedRates,
            localUiFramePacingFps = measuredUiFps.coerceAtMost(refreshHz ?: 120f),
            externalGameFpsStatus = "Not supported (OS Sandbox)",
            thermalStatusLabel = thermalLabel,
            thermalSeverityLevel = thermalSeverity,
            networkConnected = netConnected,
            networkTransportLabel = transportLabel,
            networkDownstreamKbps = downKbps
        )
    }

    fun evaluateGamingReadiness(snapshot: TelemetrySnapshot): List<ReadinessCheckItem> {
        val items = mutableListOf<ReadinessCheckItem>()

        // 1. Memory Check
        val ramLevel = when {
            snapshot.isLowMemory || snapshot.ramUsagePercent >= 88f -> ReadinessLevel.ATTENTION
            snapshot.ramUsagePercent >= 76f -> ReadinessLevel.CAUTION
            else -> ReadinessLevel.OPTIMAL
        }
        val ramRec = when (ramLevel) {
            ReadinessLevel.OPTIMAL -> "Sufficient free RAM (${snapshot.ramAvailableMb} MB available) for smooth texture caching."
            ReadinessLevel.CAUTION -> "Moderate memory load (${snapshot.ramUsagePercent.roundToInt()}%). Consider closing unused background apps manually before launching your game."
            ReadinessLevel.ATTENTION -> "High memory pressure detected (${snapshot.ramAvailableMb} MB free). Close heavy background apps via Android system settings to reduce asset reload stutters."
            ReadinessLevel.UNSUPPORTED -> "Memory information unavailable."
        }
        items.add(
            ReadinessCheckItem(
                title = "System Memory (RAM)",
                currentValue = "${snapshot.ramAvailableMb} MB Free / ${snapshot.ramTotalMb} MB Total",
                status = ramLevel,
                recommendation = ramRec
            )
        )

        // 2. Storage Check
        val storageLevel = when {
            snapshot.storageAvailableGb < 2.0f -> ReadinessLevel.ATTENTION
            snapshot.storageAvailableGb < 5.0f -> ReadinessLevel.CAUTION
            else -> ReadinessLevel.OPTIMAL
        }
        val storageRec = when (storageLevel) {
            ReadinessLevel.OPTIMAL -> String.format(Locale.US, "%.1f GB free internal storage — ample space for shader compilation & resource packs.", snapshot.storageAvailableGb)
            ReadinessLevel.CAUTION -> String.format(Locale.US, "Only %.1f GB free. Consider clearing old media or cache if downloading game expansion packs.", snapshot.storageAvailableGb)
            ReadinessLevel.ATTENTION -> String.format(Locale.US, "Low storage (%.1f GB free). Android storage I/O may slow down when internal flash is nearly full.", snapshot.storageAvailableGb)
            ReadinessLevel.UNSUPPORTED -> "Storage reading not supported."
        }
        items.add(
            ReadinessCheckItem(
                title = "Internal Flash Storage",
                currentValue = String.format(Locale.US, "%.1f GB Available (%.0f%% Used)", snapshot.storageAvailableGb, snapshot.storageUsagePercent),
                status = storageLevel,
                recommendation = storageRec
            )
        )

        // 3. Battery & Thermal Check
        val battPct = snapshot.batteryPercent
        val tempC = snapshot.batteryTempCelsius
        val battLevel = when {
            battPct == null -> ReadinessLevel.UNSUPPORTED
            (tempC != null && tempC >= 43f) || snapshot.thermalSeverityLevel >= 3 -> ReadinessLevel.ATTENTION
            battPct < 20 || (tempC != null && tempC >= 39f) || snapshot.thermalSeverityLevel == 2 -> ReadinessLevel.CAUTION
            else -> ReadinessLevel.OPTIMAL
        }
        val tempText = if (tempC != null) String.format(Locale.US, "%.1f°C", tempC) else "Temp: Not supported"
        val battText = if (battPct != null) "$battPct% ($tempText)" else "Not supported"
        val battRec = when (battLevel) {
            ReadinessLevel.OPTIMAL -> "Battery charge and temperature are within normal operating margins."
            ReadinessLevel.CAUTION -> if (snapshot.isCharging && (tempC ?: 0f) >= 38f) {
                "Charging while gaming generates extra heat. Unplugging during intense matches can help reduce thermal throttling."
            } else {
                "Battery is below 20% or moderately warm. Avoid heavy background downloads while playing."
            }
            ReadinessLevel.ATTENTION -> "Elevated device temperature detected. Allow the device to rest in a ventilated area and remove thick cases if warm."
            ReadinessLevel.UNSUPPORTED -> "Battery sensor data not supported on this device."
        }
        items.add(
            ReadinessCheckItem(
                title = "Battery & Thermal State",
                currentValue = "$battText • ${snapshot.thermalStatusLabel}",
                status = battLevel,
                recommendation = battRec
            )
        )

        // 4. Display Capabilities
        val hz = snapshot.displayRefreshRateHz
        val dispLevel = if (hz == null) ReadinessLevel.UNSUPPORTED else ReadinessLevel.OPTIMAL
        val dispValue = if (hz != null) "${snapshot.resolutionLabel} @ ${hz.roundToInt()}Hz" else snapshot.resolutionLabel
        val dispRec = if (hz != null && hz >= 90f) {
            "High refresh display (${hz.roundToInt()}Hz) active. Ensure High FPS mode is also enabled manually inside your game's graphics settings."
        } else {
            "Standard 60Hz display refresh rate active. Match in-game sensitivity to 60Hz touch pacing."
        }
        items.add(
            ReadinessCheckItem(
                title = "Display & Refresh Rate",
                currentValue = dispValue,
                status = dispLevel,
                recommendation = dispRec
            )
        )

        // 5. Network Connection
        val netLevel = when {
            !snapshot.networkConnected -> ReadinessLevel.ATTENTION
            snapshot.networkTransportLabel.contains("Wi-Fi") || snapshot.networkTransportLabel.contains("Ethernet") -> ReadinessLevel.OPTIMAL
            else -> ReadinessLevel.CAUTION
        }
        val netRec = when (netLevel) {
            ReadinessLevel.OPTIMAL -> "${snapshot.networkTransportLabel} connected. Use the Latency Tester tab to verify packet round-trip stability."
            ReadinessLevel.CAUTION -> "${snapshot.networkTransportLabel} active. A 5GHz Wi-Fi connection typically offers lower jitter for competitive matches."
            ReadinessLevel.ATTENTION -> "No active internet connection detected. Enable Wi-Fi or Mobile Data before starting online matches."
            ReadinessLevel.UNSUPPORTED -> "Network status unavailable."
        }
        items.add(
            ReadinessCheckItem(
                title = "Network Connectivity",
                currentValue = snapshot.networkTransportLabel,
                status = netLevel,
                recommendation = netRec
            )
        )

        return items
    }

    suspend fun runAuthorizedLatencyTest(
        endpointUrl: String,
        sampleCount: Int = 4
    ): LatencyTestResult = withContext(Dispatchers.IO) {
        val cleanUrl = endpointUrl.trim()
        if (!cleanUrl.startsWith("https://") && !cleanUrl.startsWith("http://")) {
            return@withContext LatencyTestResult(
                endpoint = cleanUrl,
                success = false,
                errorMessage = "Endpoint must start with https:// or http://"
            )
        }
        val samples = mutableListOf<Long>()
        var lastError: String? = null

        for (i in 0 until sampleCount.coerceIn(1, 6)) {
            val startNs = System.nanoTime()
            try {
                val conn = (URL(cleanUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "HEAD"
                    connectTimeout = 3500
                    readTimeout = 3500
                    instanceFollowRedirects = false
                    useCaches = false
                }
                conn.connect()
                val code = conn.responseCode
                conn.disconnect()
                if (code in 100..599) {
                    val rttMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                    samples.add(rttMs)
                }
            } catch (e: Exception) {
                lastError = e.localizedMessage ?: "Connection timeout or unreachable host"
            }
        }

        if (samples.isEmpty()) {
            LatencyTestResult(
                endpoint = cleanUrl,
                success = false,
                errorMessage = lastError ?: "Host unreachable"
            )
        } else {
            val min = samples.minOrNull() ?: 0L
            val max = samples.maxOrNull() ?: 0L
            val avg = samples.average().roundToInt().toLong()
            val jitter = if (samples.size > 1) {
                samples.zipWithNext { a, b -> abs(a - b) }.average().roundToInt().toLong()
            } else {
                0L
            }
            LatencyTestResult(
                endpoint = cleanUrl,
                success = true,
                samplesMs = samples,
                minMs = min,
                avgMs = avg,
                maxMs = max,
                jitterMs = jitter
            )
        }
    }

    fun inspectAppIntegrity(): AppIntegrityReport {
        val pkgName = context.packageName
        val pm = context.packageManager
        val versionName = runCatching {
            pm.getPackageInfo(pkgName, 0).versionName ?: "1.0"
        }.getOrDefault("1.0")

        val sigHash = runCatching {
            @Suppress("DEPRECATION")
            val bytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNING_CERTIFICATES)
                info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                val info = pm.getPackageInfo(pkgName, PackageManager.GET_SIGNATURES)
                info.signatures?.firstOrNull()?.toByteArray()
            }
            if (bytes != null) {
                val md = MessageDigest.getInstance("SHA-256").digest(bytes)
                md.take(12).joinToString(":") { "%02X".format(it) } + "..."
            } else {
                "Verified Local APK"
            }
        }.getOrDefault("Verified Sandbox Build")

        val installer = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                pm.getInstallSourceInfo(pkgName).installingPackageName ?: "ADB / Direct Install"
            } else {
                @Suppress("DEPRECATION")
                pm.getInstallerPackageName(pkgName) ?: "ADB / Direct Install"
            }
        }.getOrDefault("Local Package Installer")

        val isDebug = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val canOverlay = Settings.canDrawOverlays(context)
        val hasNetState = context.checkSelfPermission(android.Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
        val hasVibrate = context.checkSelfPermission(android.Manifest.permission.VIBRATE) == PackageManager.PERMISSION_GRANTED

        return AppIntegrityReport(
            packageName = pkgName,
            versionName = versionName,
            signatureSha256 = sigHash,
            installerSource = installer,
            isDebugBuild = isDebug,
            overlayPermissionGranted = canOverlay,
            networkStateGranted = hasNetState,
            vibrateGranted = hasVibrate
        )
    }

    fun buildDiagnosticReportJson(
        snapshot: TelemetrySnapshot,
        historyRam: List<Float>,
        lastLatency: LatencyTestResult?
    ): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        return JSONObject().apply {
            put("reportTitle", "Ghost Aura Pro — Hardware & Readiness Diagnostic Report")
            put("generatedAt", sdf.format(Date(snapshot.timestampMs)))
            put("device", snapshot.deviceManufacturerModel)
            put("os", snapshot.androidVersionLabel)
            put("cpu", "${snapshot.cpuAbi} (${snapshot.cpuCores} cores)")
            put("memory", JSONObject().apply {
                put("totalMb", snapshot.ramTotalMb)
                put("availableMb", snapshot.ramAvailableMb)
                put("usedMb", snapshot.ramUsedMb)
                put("usagePercent", snapshot.ramUsagePercent.roundToInt())
                put("recentSamplesPercent", JSONArray(historyRam.map { it.roundToInt() }))
            })
            put("battery", JSONObject().apply {
                put("percent", snapshot.batteryPercent ?: "Not supported")
                put("temperatureCelsius", snapshot.batteryTempCelsius ?: "Not supported")
                put("charging", snapshot.isCharging)
                put("health", snapshot.batteryHealthLabel)
                put("thermalStatus", snapshot.thermalStatusLabel)
            })
            put("storage", JSONObject().apply {
                put("totalGb", String.format(Locale.US, "%.2f", snapshot.storageTotalGb))
                put("availableGb", String.format(Locale.US, "%.2f", snapshot.storageAvailableGb))
                put("usagePercent", snapshot.storageUsagePercent.roundToInt())
            })
            put("display", JSONObject().apply {
                put("resolution", snapshot.resolutionLabel)
                put("densityDpi", snapshot.densityDpi)
                put("refreshRateHz", snapshot.displayRefreshRateHz?.roundToInt() ?: "Not supported")
                put("appUiFramePacingFps", snapshot.localUiFramePacingFps.roundToInt())
                put("externalGameFpsNote", snapshot.externalGameFpsStatus)
            })
            put("network", JSONObject().apply {
                put("connected", snapshot.networkConnected)
                put("transport", snapshot.networkTransportLabel)
                if (lastLatency != null && lastLatency.success) {
                    put("lastLatencyTestEndpoint", lastLatency.endpoint)
                    put("avgLatencyMs", lastLatency.avgMs)
                    put("jitterMs", lastLatency.jitterMs)
                }
            })
        }.toString(2)
    }
}
