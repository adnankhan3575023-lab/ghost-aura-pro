package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian & Charcoal Cyberpunk Surfaces
val ObsidianBlack = Color(0xFF07080D)
val CharcoalSurface = Color(0xFF0F121C)
val CharcoalElevated = Color(0xFF171B2B)
val CharcoalGlass = Color(0xCC161A29)
val CyberBorderDim = Color(0xFF282F47)

// Light Theme Surfaces (when Light mode is explicitly chosen)
val CyberLightBg = Color(0xFFF3F5FA)
val CyberLightSurface = Color(0xFFFFFFFF)
val CyberLightElevated = Color(0xFFE7ECF6)

// Neon Accents
val NeonPurple = Color(0xFFA855F7)
val NeonPurpleGlow = Color(0xFF9333EA)
val ElectricBlue = Color(0xFF00F0FF)
val ElectricBlueDim = Color(0xFF0284C7)
val RestrainedGreen = Color(0xFF10B981)
val CyberAmber = Color(0xFFF59E0B)
val CyberCrimson = Color(0xFFF43F5E)

// Text Colors
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

enum class AccentPalette(
    val id: Int,
    val label: String,
    val primary: Color,
    val secondary: Color,
    val tertiary: Color
) {
    PHANTOM_PURPLE(0, "Phantom Purple", NeonPurple, ElectricBlue, RestrainedGreen),
    ELECTRIC_CYAN(1, "Electric Blue", ElectricBlue, NeonPurple, RestrainedGreen),
    MATRIX_EMERALD(2, "Restrained Green", RestrainedGreen, ElectricBlue, NeonPurple),
    CRIMSON_OVERDRIVE(3, "Crimson Pulse", CyberCrimson, ElectricBlue, RestrainedGreen);

    companion object {
        fun fromId(id: Int): AccentPalette = entries.find { it.id == id } ?: PHANTOM_PURPLE
    }
}
