package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.data.SensitivityPresetEntity
import com.example.monitoring.TelemetrySnapshot
import com.example.ui.LiveCrosshairEditorState
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RestrainedGreen
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

fun parseHexColorSafe(hex: String, fallback: Color = ElectricBlue): Color {
    return runCatching {
        Color(android.graphics.Color.parseColor(hex))
    }.getOrDefault(fallback)
}

@Composable
fun GhostAuraLogoCanvas(
    modifier: Modifier = Modifier.size(54.dp),
    animationIntensity: Float = 1f,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    secondaryColor: Color = MaterialTheme.colorScheme.secondary
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ghost_aura_logo")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "logo_rot"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.86f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "logo_pulse"
    )

    val effectiveRot = if (animationIntensity > 0.05f) rotation * animationIntensity else 0f
    val effectivePulse = if (animationIntensity > 0.05f) pulse else 1f

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f

        // Outer spectral aura glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    primaryColor.copy(alpha = 0.35f * effectivePulse),
                    secondaryColor.copy(alpha = 0.12f),
                    Color.Transparent
                ),
                center = Offset(cx, cy),
                radius = r
            ),
            radius = r,
            center = Offset(cx, cy)
        )

        // Rotating cyber reticle ring
        rotate(degrees = effectiveRot, pivot = Offset(cx, cy)) {
            drawCircle(
                color = secondaryColor.copy(alpha = 0.65f),
                radius = r * 0.78f,
                center = Offset(cx, cy),
                style = Stroke(width = 1.8.dp.toPx())
            )
            val tick = r * 0.16f
            drawLine(secondaryColor, Offset(cx, cy - r * 0.88f), Offset(cx, cy - r * 0.66f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            drawLine(secondaryColor, Offset(cx, cy + r * 0.66f), Offset(cx, cy + r * 0.88f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            drawLine(secondaryColor, Offset(cx - r * 0.88f, cy), Offset(cx - r * 0.66f, cy), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            drawLine(secondaryColor, Offset(cx + r * 0.66f, cy), Offset(cx + r * 0.88f, cy), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            // Corner arcs
            drawCircle(primaryColor, radius = tick * 0.25f, center = Offset(cx, cy - r * 0.78f))
        }

        // Inner Ghost Shield Crest
        val shieldPath = Path().apply {
            moveTo(cx, cy - r * 0.54f)
            lineTo(cx + r * 0.44f, cy - r * 0.32f)
            lineTo(cx + r * 0.36f, cy + r * 0.22f)
            lineTo(cx, cy + r * 0.56f)
            lineTo(cx - r * 0.36f, cy + r * 0.22f)
            lineTo(cx - r * 0.44f, cy - r * 0.32f)
            close()
        }
        drawPath(
            path = shieldPath,
            brush = Brush.linearGradient(
                colors = listOf(primaryColor.copy(alpha = 0.35f), secondaryColor.copy(alpha = 0.2f))
            )
        )
        drawPath(
            path = shieldPath,
            color = primaryColor,
            style = Stroke(width = 2.dp.toPx())
        )

        // Cyber Ghost Visor Eyes
        drawLine(
            color = secondaryColor,
            start = Offset(cx - r * 0.24f, cy - r * 0.06f),
            end = Offset(cx - r * 0.06f, cy + r * 0.02f),
            strokeWidth = 2.5.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = secondaryColor,
            start = Offset(cx + r * 0.24f, cy - r * 0.06f),
            end = Offset(cx + r * 0.06f, cy + r * 0.02f),
            strokeWidth = 2.5.dp.toPx(),
            cap = StrokeCap.Round
        )
        // Core Dot
        drawCircle(
            color = RestrainedGreen,
            radius = r * 0.08f,
            center = Offset(cx, cy + r * 0.22f)
        )
    }
}

@Composable
fun CyberGlassCard(
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    glowStrength: Float = 0.25f,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val cardModifier = if (onClick != null) {
        modifier
            .clip(shape)
            .clickable { onClick() }
    } else {
        modifier.clip(shape)
    }

    Surface(
        modifier = cardModifier,
        shape = shape,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.90f),
        border = BorderStroke(
            width = 1.dp,
            brush = Brush.linearGradient(
                colors = listOf(
                    accentColor.copy(alpha = (0.55f * glowStrength).coerceIn(0.15f, 0.85f)),
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                    accentColor.copy(alpha = (0.35f * glowStrength).coerceIn(0.10f, 0.65f))
                )
            )
        ),
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            content = content
        )
    }
}

@Composable
fun AnimatedStatusBadge(
    label: String,
    color: Color = RestrainedGreen,
    animationIntensity: Float = 1f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "status_badge")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot_alpha"
    )
    val effectiveAlpha = if (animationIntensity > 0.05f) alpha else 1f

    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = effectiveAlpha))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = color,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun TelemetryLineChart(
    dataPoints: List<Float>,
    minValue: Float = 0f,
    maxValue: Float = 100f,
    lineColor: Color = ElectricBlue,
    unitSuffix: String = "%",
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .height(110.dp)
) {
    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val gridColor = lineColor.copy(alpha = 0.12f)

            // Horizontal HUD grid lines
            for (i in 0..3) {
                val y = (h / 3f) * i
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            if (dataPoints.isEmpty()) return@Canvas

            val safeRange = (maxValue - minValue).coerceAtLeast(1f)
            val points = if (dataPoints.size == 1) {
                listOf(dataPoints.first(), dataPoints.first())
            } else {
                dataPoints
            }

            val stepX = w / (points.size - 1).coerceAtLeast(1)
            val linePath = Path()
            val fillPath = Path()

            points.forEachIndexed { idx, value ->
                val normalized = ((value - minValue) / safeRange).coerceIn(0f, 1f)
                val x = idx * stepX
                val y = h - (normalized * (h * 0.84f)) - (h * 0.08f)
                if (idx == 0) {
                    linePath.moveTo(x, y)
                    fillPath.moveTo(x, h)
                    fillPath.lineTo(x, y)
                } else {
                    linePath.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
                if (idx == points.lastIndex) {
                    fillPath.lineTo(x, h)
                    fillPath.close()
                }
            }

            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        lineColor.copy(alpha = 0.30f),
                        lineColor.copy(alpha = 0.02f)
                    )
                )
            )

            drawPath(
                path = linePath,
                color = lineColor,
                style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
            )

            // Latest point glow dot
            val lastVal = points.last()
            val lastNorm = ((lastVal - minValue) / safeRange).coerceIn(0f, 1f)
            val lastY = h - (lastNorm * (h * 0.84f)) - (h * 0.08f)
            drawCircle(
                color = lineColor.copy(alpha = 0.35f),
                radius = 7.dp.toPx(),
                center = Offset(w, lastY)
            )
            drawCircle(
                color = lineColor,
                radius = 3.5.dp.toPx(),
                center = Offset(w, lastY)
            )
        }

        if (dataPoints.isNotEmpty()) {
            val minSample = dataPoints.minOrNull()?.roundToInt() ?: 0
            val maxSample = dataPoints.maxOrNull()?.roundToInt() ?: 0
            val latest = dataPoints.last().roundToInt()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopStart)
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "MIN: $minSample$unitSuffix  MAX: $maxSample$unitSuffix",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "NOW: $latest$unitSuffix",
                    style = MaterialTheme.typography.labelSmall,
                    color = lineColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun CrosshairReticleCanvas(
    styleIndex: Int,
    sizeDp: Float,
    thicknessDp: Float,
    gapDp: Float,
    showCenterDot: Boolean,
    showOutline: Boolean,
    colorHex: String,
    opacity: Float,
    rotationDeg: Float,
    modifier: Modifier = Modifier.size(160.dp)
) {
    val baseColor = parseHexColorSafe(colorHex, ElectricBlue)
    val mainColor = baseColor.copy(alpha = opacity.coerceIn(0.15f, 1f))
    val outlineColor = Color.Black.copy(alpha = (opacity * 0.85f).coerceIn(0.15f, 0.95f))

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val lenPx = (sizeDp / 2f).dp.toPx()
        val gapPx = gapDp.dp.toPx()
        val thickPx = thicknessDp.dp.toPx().coerceAtLeast(1.5f)
        val outlineThickPx = thickPx + 2.5.dp.toPx()

        rotate(degrees = rotationDeg, pivot = Offset(cx, cy)) {
            if (showOutline) {
                drawReticleStyle(
                    styleIndex = styleIndex,
                    cx = cx,
                    cy = cy,
                    lenPx = lenPx,
                    gapPx = gapPx,
                    strokePx = outlineThickPx,
                    color = outlineColor
                )
            }
            drawReticleStyle(
                styleIndex = styleIndex,
                cx = cx,
                cy = cy,
                lenPx = lenPx,
                gapPx = gapPx,
                strokePx = thickPx,
                color = mainColor
            )

            if (showCenterDot) {
                val dotRadius = (thickPx * 0.85f).coerceAtLeast(2.2.dp.toPx())
                if (showOutline) {
                    drawCircle(
                        color = outlineColor,
                        radius = dotRadius + 1.2.dp.toPx(),
                        center = Offset(cx, cy)
                    )
                }
                drawCircle(
                    color = mainColor,
                    radius = dotRadius,
                    center = Offset(cx, cy)
                )
            }
        }
    }
}

private fun DrawScope.drawReticleStyle(
    styleIndex: Int,
    cx: Float,
    cy: Float,
    lenPx: Float,
    gapPx: Float,
    strokePx: Float,
    color: Color
) {
    when (styleIndex) {
        0 -> { // Classic Tactical Cross
            drawLine(color, Offset(cx - gapPx - lenPx, cy), Offset(cx - gapPx, cy), strokePx, StrokeCap.Square)
            drawLine(color, Offset(cx + gapPx, cy), Offset(cx + gapPx + lenPx, cy), strokePx, StrokeCap.Square)
            drawLine(color, Offset(cx, cy - gapPx - lenPx), Offset(cx, cy - gapPx), strokePx, StrokeCap.Square)
            drawLine(color, Offset(cx, cy + gapPx), Offset(cx, cy + gapPx + lenPx), strokePx, StrokeCap.Square)
        }
        1 -> { // Precision Dot + Cross (Rounded)
            drawLine(color, Offset(cx - gapPx - lenPx, cy), Offset(cx - gapPx, cy), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx + gapPx, cy), Offset(cx + gapPx + lenPx, cy), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx, cy - gapPx - lenPx), Offset(cx, cy - gapPx), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx, cy + gapPx), Offset(cx, cy + gapPx + lenPx), strokePx, StrokeCap.Round)
        }
        2 -> { // Cyber Chevron Apex
            val apexY = cy - gapPx * 0.5f
            drawLine(color, Offset(cx, apexY), Offset(cx - lenPx, apexY + lenPx), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx, apexY), Offset(cx + lenPx, apexY + lenPx), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx - lenPx * 0.55f, apexY + lenPx * 1.25f), Offset(cx + lenPx * 0.55f, apexY + lenPx * 1.25f), strokePx * 0.8f, StrokeCap.Round)
        }
        3 -> { // Orbital Circle + Dot
            val radius = (lenPx + gapPx).coerceAtLeast(6f)
            drawCircle(color, radius = radius, center = Offset(cx, cy), style = Stroke(width = strokePx))
        }
        4 -> { // Tactical Box Bracket
            val d = (gapPx + lenPx * 0.85f).coerceAtLeast(6f)
            val arm = (lenPx * 0.55f).coerceAtLeast(4f)
            // Top-Left
            drawLine(color, Offset(cx - d, cy - d), Offset(cx - d + arm, cy - d), strokePx, StrokeCap.Square)
            drawLine(color, Offset(cx - d, cy - d), Offset(cx - d, cy - d + arm), strokePx, StrokeCap.Square)
            // Top-Right
            drawLine(color, Offset(cx + d, cy - d), Offset(cx + d - arm, cy - d), strokePx, StrokeCap.Square)
            drawLine(color, Offset(cx + d, cy - d), Offset(cx + d, cy - d + arm), strokePx, StrokeCap.Square)
            // Bottom-Left
            drawLine(color, Offset(cx - d, cy + d), Offset(cx - d + arm, cy + d), strokePx, StrokeCap.Square)
            drawLine(color, Offset(cx - d, cy + d), Offset(cx - d, cy + d - arm), strokePx, StrokeCap.Square)
            // Bottom-Right
            drawLine(color, Offset(cx + d, cy + d), Offset(cx + d - arm, cy + d), strokePx, StrokeCap.Square)
            drawLine(color, Offset(cx + d, cy + d), Offset(cx + d, cy + d - arm), strokePx, StrokeCap.Square)
        }
        5 -> { // Diamond Nexus
            val r = (gapPx + lenPx).coerceAtLeast(6f)
            val path = Path().apply {
                moveTo(cx, cy - r)
                lineTo(cx + r, cy)
                lineTo(cx, cy + r)
                lineTo(cx - r, cy)
                close()
            }
            drawPath(path, color = color, style = Stroke(width = strokePx))
        }
        6 -> { // Ballistic T-Post
            drawLine(color, Offset(cx - gapPx - lenPx, cy), Offset(cx - gapPx, cy), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx + gapPx, cy), Offset(cx + gapPx + lenPx, cy), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx, cy + gapPx), Offset(cx, cy + gapPx + lenPx * 1.25f), strokePx, StrokeCap.Round)
            // Elevation drop ticks
            val tickW = lenPx * 0.35f
            drawLine(color, Offset(cx - tickW, cy + gapPx + lenPx * 0.55f), Offset(cx + tickW, cy + gapPx + lenPx * 0.55f), strokePx * 0.75f, StrokeCap.Round)
        }
        7 -> { // Dual Wing Stabilizer
            val wingY = lenPx * 0.45f
            drawLine(color, Offset(cx - gapPx - lenPx, cy), Offset(cx - gapPx, cy), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx + gapPx, cy), Offset(cx + gapPx + lenPx, cy), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx - gapPx, cy - wingY), Offset(cx - gapPx, cy + wingY), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx + gapPx, cy - wingY), Offset(cx + gapPx, cy + wingY), strokePx, StrokeCap.Round)
        }
        8 -> { // Hexagonal Apogee
            val r = (gapPx + lenPx).coerceAtLeast(7f)
            val hexPath = Path()
            for (i in 0..5) {
                val rad = Math.toRadians((i * 60.0) - 30.0)
                val px = cx + (r * cos(rad)).toFloat()
                val py = cy + (r * sin(rad)).toFloat()
                if (i == 0) hexPath.moveTo(px, py) else hexPath.lineTo(px, py)
            }
            hexPath.close()
            drawPath(hexPath, color = color, style = Stroke(width = strokePx))
        }
        9 -> { // Tri-Beam Predator
            for (angle in listOf(-90.0, 30.0, 150.0)) {
                val rad = Math.toRadians(angle)
                val sx = cx + (gapPx * cos(rad)).toFloat()
                val sy = cy + (gapPx * sin(rad)).toFloat()
                val ex = cx + ((gapPx + lenPx) * cos(rad)).toFloat()
                val ey = cy + ((gapPx + lenPx) * sin(rad)).toFloat()
                drawLine(color, Offset(sx, sy), Offset(ex, ey), strokePx, StrokeCap.Round)
            }
        }
        10 -> { // Octa-Ring Radar
            val r = (gapPx + lenPx * 0.8f).coerceAtLeast(6f)
            drawCircle(color, radius = r, center = Offset(cx, cy), style = Stroke(width = strokePx * 0.85f))
            for (angle in listOf(0.0, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0)) {
                val rad = Math.toRadians(angle)
                val sx = cx + ((r - strokePx * 1.2f) * cos(rad)).toFloat()
                val sy = cy + ((r - strokePx * 1.2f) * sin(rad)).toFloat()
                val ex = cx + ((r + lenPx * 0.35f) * cos(rad)).toFloat()
                val ey = cy + ((r + lenPx * 0.35f) * sin(rad)).toFloat()
                drawLine(color, Offset(sx, sy), Offset(ex, ey), strokePx * 0.85f, StrokeCap.Round)
            }
        }
        else -> { // 11: Ghost Aura Pulse (Concentric + Cross)
            val innerR = (gapPx + lenPx * 0.45f).coerceAtLeast(5f)
            val outerR = (gapPx + lenPx).coerceAtLeast(10f)
            drawCircle(color, radius = innerR, center = Offset(cx, cy), style = Stroke(width = strokePx * 0.8f))
            drawLine(color, Offset(cx - outerR, cy), Offset(cx - gapPx, cy), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx + gapPx, cy), Offset(cx + outerR, cy), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx, cy - outerR), Offset(cx, cy - gapPx), strokePx, StrokeCap.Round)
            drawLine(color, Offset(cx, cy + gapPx), Offset(cx, cy + outerR), strokePx, StrokeCap.Round)
        }
    }
}

@Composable
fun SimulatedArenaPreviewBox(
    editorState: LiveCrosshairEditorState,
    modifier: Modifier = Modifier
        .fillMaxWidth()
        .height(220.dp)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arena_target")
    val targetOffsetNorm by infiniteTransition.animateFloat(
        initialValue = -0.28f,
        targetValue = 0.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "target_strafe"
    )

    val sceneBgBrush = when (editorState.backgroundSceneIndex) {
        0 -> Brush.verticalGradient(listOf(Color(0xFF090D18), Color(0xFF151E32), Color(0xFF0B0F1A))) // Tactical Night Range
        1 -> Brush.verticalGradient(listOf(Color(0xFF070510), Color(0xFF1A0E2E), Color(0xFF090A14))) // Cyber Grid
        2 -> Brush.verticalGradient(listOf(Color(0xFF2B192E), Color(0xFF47293B), Color(0xFF181A24))) // Dusk Horizon
        else -> Brush.verticalGradient(listOf(Color(0xFF7DD3FC), Color(0xFFBAE6FD), Color(0xFF94A3B8))) // High Contrast Daylight
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(sceneBgBrush)
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f), RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
    ) {
        // Simulated Range Perspective Grid & Target Silhouette
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val horizonY = h * 0.54f
            val gridLineColor = if (editorState.backgroundSceneIndex == 3) {
                Color.Black.copy(alpha = 0.15f)
            } else {
                ElectricBlue.copy(alpha = 0.16f)
            }

            // Horizon line
            drawLine(gridLineColor, Offset(0f, horizonY), Offset(w, horizonY), strokeWidth = 1.5.dp.toPx())

            // Perspective floor rays
            for (i in -4..4) {
                val bottomX = (w / 2f) + (i * (w * 0.18f))
                drawLine(
                    color = gridLineColor,
                    start = Offset(w / 2f, horizonY),
                    end = Offset(bottomX, h),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Distance range rings / markers
            val targetX = if (editorState.movingTargetDemo) {
                (w / 2f) + (targetOffsetNorm * w)
            } else {
                w / 2f
            }
            val targetY = h * 0.50f

            // Simulated Training Bot Silhouette at 25m
            val silColor = if (editorState.backgroundSceneIndex == 3) {
                Color(0xFF1E293B).copy(alpha = 0.75f)
            } else {
                NeonPurple.copy(alpha = 0.32f)
            }
            val headR = 10.dp.toPx()
            drawCircle(
                color = silColor,
                radius = headR,
                center = Offset(targetX, targetY - 18.dp.toPx())
            )
            drawCircle(
                color = ElectricBlue.copy(alpha = 0.55f),
                radius = headR,
                center = Offset(targetX, targetY - 18.dp.toPx()),
                style = Stroke(width = 1.5.dp.toPx())
            )
            drawRoundRect(
                color = silColor,
                topLeft = Offset(targetX - 16.dp.toPx(), targetY - 5.dp.toPx()),
                size = Size(32.dp.toPx(), 42.dp.toPx()),
                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
            )
        }

        // Live Crosshair Centered in Preview
        CrosshairReticleCanvas(
            styleIndex = editorState.styleIndex,
            sizeDp = editorState.sizeDp,
            thicknessDp = editorState.thicknessDp,
            gapDp = editorState.gapDp,
            showCenterDot = editorState.showCenterDot,
            showOutline = editorState.showOutline,
            colorHex = editorState.colorHex,
            opacity = editorState.opacity,
            rotationDeg = editorState.rotationDeg,
            modifier = Modifier.size(160.dp)
        )

        // Top HUD labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopStart)
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "SIMULATED RANGE // 25M TARGET",
                style = MaterialTheme.typography.labelSmall,
                color = if (editorState.backgroundSceneIndex == 3) Color.Black else ElectricBlue
            )
            Text(
                text = "${editorState.sizeDp.roundToInt()}DP • ${(editorState.opacity * 100).roundToInt()}% ALPHA",
                style = MaterialTheme.typography.labelSmall,
                color = if (editorState.backgroundSceneIndex == 3) Color.Black else NeonPurple
            )
        }
    }
}

@Composable
fun InAppFloatingBubbleOverlay(
    bubbleSizeDp: Int,
    bubbleOpacity: Float,
    bubbleColorHex: String,
    telemetry: TelemetrySnapshot,
    activeSensitivity: SensitivityPresetEntity?,
    editorState: LiveCrosshairEditorState,
    onCloseBubble: () -> Unit,
    onJumpToSensitivity: () -> Unit,
    onJumpToCrosshair: () -> Unit
) {
    var offsetX by remember { mutableFloatStateOf(24f) }
    var offsetY by remember { mutableFloatStateOf(160f) }
    var isExpanded by remember { mutableStateOf(false) }
    var showInAppReticle by remember { mutableStateOf(false) }

    val accentColor = parseHexColorSafe(bubbleColorHex, NeonPurple)

    Box(modifier = Modifier.fillMaxSize()) {
        // Optional in-app centered reticle preview toggled from the floating bubble
        if (showInAppReticle) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CrosshairReticleCanvas(
                    styleIndex = editorState.styleIndex,
                    sizeDp = editorState.sizeDp,
                    thicknessDp = editorState.thicknessDp,
                    gapDp = editorState.gapDp,
                    showCenterDot = editorState.showCenterDot,
                    showOutline = editorState.showOutline,
                    colorHex = editorState.colorHex,
                    opacity = editorState.opacity,
                    rotationDeg = editorState.rotationDeg
                )
            }
        }

        Column(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX = (offsetX + dragAmount.x).coerceIn(0f, 800f)
                        offsetY = (offsetY + dragAmount.y).coerceIn(40f, 1600f)
                    }
                }
        ) {
            // Draggable Bubble Button
            Surface(
                modifier = Modifier
                    .size(bubbleSizeDp.dp)
                    .clickable { isExpanded = !isExpanded }
                    .testTag("floating_bubble_handle"),
                shape = CircleShape,
                color = Color(0xFF0F121C).copy(alpha = bubbleOpacity),
                border = BorderStroke(2.dp, accentColor),
                shadowElevation = 8.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    GhostAuraLogoCanvas(
                        modifier = Modifier.size((bubbleSizeDp * 0.72f).dp),
                        primaryColor = accentColor,
                        secondaryColor = ElectricBlue
                    )
                }
            }

            // Expandable Quick-Access Utility Card
            AnimatedVisibility(visible = isExpanded) {
                Surface(
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .width(250.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF0A0D16).copy(alpha = (bubbleOpacity + 0.05f).coerceAtMost(0.98f)),
                    border = BorderStroke(1.5.dp, accentColor)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "GHOST AURA HUD",
                                style = MaterialTheme.typography.labelLarge,
                                color = accentColor,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = onCloseBubble,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close floating bubble",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        val tempText = telemetry.batteryTempCelsius?.let { "${it.roundToInt()}°C" } ?: "N/A"
                        val hzText = telemetry.displayRefreshRateHz?.let { "${it.roundToInt()}Hz" } ?: "60Hz"
                        Text(
                            text = "RAM: ${telemetry.ramUsagePercent.roundToInt()}% • BATT: ${telemetry.batteryPercent ?: "--"}% ($tempText) • $hzText",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricBlue
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = activeSensitivity?.let {
                                "${it.name}: Gen ${it.general} | Red ${it.redDot} | 2x ${it.scope2x} | 4x ${it.scope4x}"
                            } ?: "Sensitivity: Default Reference",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = accentColor.copy(alpha = 0.2f),
                                modifier = Modifier.clickable {
                                    showInAppReticle = !showInAppReticle
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.GpsFixed, contentDescription = null, tint = accentColor, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (showInAppReticle) "Hide Reticle" else "Show Reticle",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = ElectricBlue.copy(alpha = 0.2f),
                                modifier = Modifier.clickable {
                                    isExpanded = false
                                    onJumpToSensitivity()
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Tune, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Presets", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = RestrainedGreen.copy(alpha = 0.2f),
                                modifier = Modifier.clickable {
                                    isExpanded = false
                                    onJumpToCrosshair()
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Speed, contentDescription = null, tint = RestrainedGreen, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Studio", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
