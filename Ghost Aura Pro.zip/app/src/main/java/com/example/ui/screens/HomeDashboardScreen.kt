package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BubbleChart
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CrosshairPresetEntity
import com.example.data.SensitivityPresetEntity
import com.example.data.UserSettingsState
import com.example.monitoring.TelemetrySnapshot
import com.example.ui.components.AnimatedStatusBadge
import com.example.ui.components.CrosshairReticleCanvas
import com.example.ui.components.CyberGlassCard
import com.example.ui.components.GhostAuraLogoCanvas
import com.example.ui.components.TelemetryLineChart
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RestrainedGreen
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun HomeDashboardScreen(
    snapshot: TelemetrySnapshot,
    ramHistory: List<Float>,
    sensitivityPresets: List<SensitivityPresetEntity>,
    crosshairPresets: List<CrosshairPresetEntity>,
    settings: UserSettingsState,
    inAppBubbleEnabled: Boolean,
    systemOverlayActive: Boolean,
    onNavigateTab: (Int) -> Unit,
    onToggleInAppBubble: (Boolean) -> Unit,
    onRequestSystemOverlay: () -> Unit,
    onSelectSensitivity: (SensitivityPresetEntity) -> Unit,
    onSelectCrosshair: (CrosshairPresetEntity) -> Unit,
    onToggleDarkTheme: (Boolean) -> Unit,
    onToggleHaptics: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_dashboard_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Hero Header with Custom Ghost Aura Logo
        item {
            CyberGlassCard(
                accentColor = MaterialTheme.colorScheme.primary,
                glowStrength = 0.65f
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        GhostAuraLogoCanvas(
                            modifier = Modifier.size(62.dp),
                            animationIntensity = settings.animationIntensity
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "GHOST AURA PRO",
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = snapshot.deviceManufacturerModel,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = "${snapshot.androidVersionLabel} • ${snapshot.cpuCores}-Core ${snapshot.cpuAbi}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    AnimatedStatusBadge(
                        label = if (snapshot.isLowMemory) "HIGH LOAD" else "ONLINE",
                        color = if (snapshot.isLowMemory) CyberAmber else RestrainedGreen,
                        animationIntensity = settings.animationIntensity
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Device Status Summary Strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusMiniMetric("NETWORK", snapshot.networkTransportLabel, ElectricBlue)
                    StatusMiniMetric("THERMAL", snapshot.thermalStatusLabel.take(12), RestrainedGreen)
                    StatusMiniMetric(
                        "REFRESH",
                        snapshot.displayRefreshRateHz?.let { "${it.roundToInt()} Hz" } ?: "Not supported",
                        NeonPurple
                    )
                }
            }
        }

        // 2. Core Hardware Telemetry Grid (2x2 Cards: RAM, Battery, Display, Storage)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // RAM Card
                    CyberGlassCard(
                        modifier = Modifier.weight(1f),
                        accentColor = ElectricBlue,
                        onClick = { onNavigateTab(3) }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Memory, contentDescription = "RAM Usage", tint = ElectricBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("RAM USAGE", style = MaterialTheme.typography.labelMedium, color = ElectricBlue)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${snapshot.ramUsagePercent.roundToInt()}%",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${snapshot.ramUsedMb} / ${snapshot.ramTotalMb} MB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { (snapshot.ramUsagePercent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = ElectricBlue,
                            trackColor = ElectricBlue.copy(alpha = 0.18f)
                        )
                    }

                    // Battery & Temperature Card
                    CyberGlassCard(
                        modifier = Modifier.weight(1f),
                        accentColor = RestrainedGreen,
                        onClick = { onNavigateTab(3) }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.BatteryChargingFull, contentDescription = "Battery", tint = RestrainedGreen, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("BATTERY", style = MaterialTheme.typography.labelMedium, color = RestrainedGreen)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = snapshot.batteryPercent?.let { "$it%" } ?: "Not supported",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val tempLabel = snapshot.batteryTempCelsius?.let {
                            String.format(Locale.US, "%.1f°C", it)
                        } ?: "Not supported"
                        Text(
                            text = "Temp: $tempLabel",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { ((snapshot.batteryPercent ?: 0) / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = RestrainedGreen,
                            trackColor = RestrainedGreen.copy(alpha = 0.18f)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Display Resolution & Refresh Rate Card
                    CyberGlassCard(
                        modifier = Modifier.weight(1f),
                        accentColor = NeonPurple,
                        onClick = { onNavigateTab(3) }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DisplaySettings, contentDescription = "Display", tint = NeonPurple, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("DISPLAY", style = MaterialTheme.typography.labelMedium, color = NeonPurple)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = snapshot.displayRefreshRateHz?.let { "${it.roundToInt()} Hz" } ?: "Not supported",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = snapshot.resolutionLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${snapshot.densityDpi} DPI • UI ${snapshot.localUiFramePacingFps.roundToInt()} FPS",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonPurple
                        )
                    }

                    // Internal Storage Card
                    CyberGlassCard(
                        modifier = Modifier.weight(1f),
                        accentColor = ElectricBlue,
                        onClick = { onNavigateTab(3) }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storage, contentDescription = "Storage", tint = ElectricBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("STORAGE", style = MaterialTheme.typography.labelMedium, color = ElectricBlue)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = String.format(Locale.US, "%.1f GB", snapshot.storageAvailableGb),
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = String.format(Locale.US, "Free of %.1f GB", snapshot.storageTotalGb),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { (snapshot.storageUsagePercent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = NeonPurple,
                            trackColor = NeonPurple.copy(alpha = 0.18f)
                        )
                    }
                }
            }
        }

        // 3. Animated Lightweight Dashboard Telemetry Graph
        item {
            CyberGlassCard(accentColor = ElectricBlue) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "LIVE MEMORY LOAD TELEMETRY",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Real-time ActivityManager RAM % samples",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "${snapshot.ramAvailableMb} MB FREE",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                TelemetryLineChart(
                    dataPoints = ramHistory,
                    minValue = 0f,
                    maxValue = 100f,
                    lineColor = ElectricBlue,
                    unitSuffix = "%"
                )
            }
        }

        // 4. Gaming Tools Shortcuts
        item {
            Text(
                text = "GAMING UTILITY MODULES",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ShortcutModuleButton(
                    title = "Sensitivity",
                    subtitle = "Free Fire Ref",
                    icon = Icons.Default.Tune,
                    accent = NeonPurple,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shortcut_sensitivity"),
                    onClick = { onNavigateTab(1) }
                )
                ShortcutModuleButton(
                    title = "Crosshair",
                    subtitle = "12 Reticles",
                    icon = Icons.Default.GpsFixed,
                    accent = ElectricBlue,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shortcut_crosshair"),
                    onClick = { onNavigateTab(2) }
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ShortcutModuleButton(
                    title = "Readiness",
                    subtitle = "Health & Ping",
                    icon = Icons.Default.Speed,
                    accent = RestrainedGreen,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shortcut_monitor"),
                    onClick = { onNavigateTab(3) }
                )
                ShortcutModuleButton(
                    title = "Cyber Deck",
                    subtitle = "Audit & Config",
                    icon = Icons.Default.Security,
                    accent = NeonPurple,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shortcut_cyber"),
                    onClick = { onNavigateTab(4) }
                )
            }
        }

        // 5. Recent Presets Carousel (Sensitivity + Crosshair)
        item {
            Text(
                text = "RECENT PRESETS & RETICLES",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(sensitivityPresets.take(4), key = { "sens_${it.id}" }) { preset ->
                    val isActive = preset.id == settings.activeSensitivityId
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isActive) NeonPurple.copy(alpha = 0.20f) else MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isActive) NeonPurple else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .width(210.dp)
                            .clickable {
                                onSelectSensitivity(preset)
                                onNavigateTab(1)
                            }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = preset.category.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonPurple
                                )
                                if (isActive) {
                                    Text("ACTIVE", style = MaterialTheme.typography.labelSmall, color = RestrainedGreen)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = preset.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Gen ${preset.general} • Red ${preset.redDot} • 2x ${preset.scope2x} • 4x ${preset.scope4x}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                items(crosshairPresets.take(4), key = { "ch_${it.id}" }) { ch ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            ElectricBlue.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .width(160.dp)
                            .clickable {
                                onSelectCrosshair(ch)
                                onNavigateTab(2)
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CrosshairReticleCanvas(
                                styleIndex = ch.styleIndex,
                                sizeDp = 18f,
                                thicknessDp = ch.thicknessDp,
                                gapDp = ch.gapDp.coerceAtMost(6f),
                                showCenterDot = ch.showCenterDot,
                                showOutline = ch.showOutline,
                                colorHex = ch.colorHex,
                                opacity = ch.opacity,
                                rotationDeg = ch.rotationDeg,
                                modifier = Modifier.size(42.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = ch.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1
                                )
                                Text(
                                    text = "Tap to Edit",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricBlue
                                )
                            }
                        }
                    }
                }
            }
        }

        // 6. Quick Settings & Floating Bubble Controls
        item {
            CyberGlassCard(accentColor = NeonPurple) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BubbleChart, contentDescription = null, tint = NeonPurple)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "QUICK ACCESS & FLOATING HUD",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Launch movable bubble or adjust core preferences",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onToggleInAppBubble(!inAppBubbleEnabled) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("toggle_inapp_bubble_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (inAppBubbleEnabled) RestrainedGreen else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(
                            text = if (inAppBubbleEnabled) "Hide In-App Bubble" else "Test Floating Bubble",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }

                    OutlinedButton(
                        onClick = onRequestSystemOverlay,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("system_overlay_quick_button")
                    ) {
                        Text(
                            text = if (systemOverlayActive) "Stop OS Overlay" else "OS Overlay HUD",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Cyber Dark Theme", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = settings.themeModeId == 0,
                        onCheckedChange = { onToggleDarkTheme(it) },
                        modifier = Modifier.testTag("quick_dark_theme_switch")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Tactile Haptic Feedback", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = settings.hapticEnabled,
                        onCheckedChange = { onToggleHaptics(it) },
                        modifier = Modifier.testTag("quick_haptic_switch")
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusMiniMetric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = color,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ShortcutModuleButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(accent.copy(alpha = 0.14f), Color.Transparent)
                    )
                )
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(accent.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = accent
                )
            }
        }
    }
}
