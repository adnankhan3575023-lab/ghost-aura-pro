package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val id: Int, val label: String) {
    DARK(0, "Cyber Dark (Default)"),
    LIGHT(1, "Tactical Light"),
    SYSTEM(2, "System Adaptive");

    companion object {
        fun fromId(id: Int): AppThemeMode = entries.find { it.id == id } ?: DARK
    }
}

@Composable
fun GhostAuraTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    accentPalette: AccentPalette = AccentPalette.PHANTOM_PURPLE,
    content: @Composable () -> Unit
) {
    val useDarkTheme = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (useDarkTheme) {
        darkColorScheme(
            primary = accentPalette.primary,
            onPrimary = Color(0xFF06070B),
            primaryContainer = accentPalette.primary.copy(alpha = 0.18f),
            onPrimaryContainer = TextPrimaryDark,
            secondary = accentPalette.secondary,
            onSecondary = Color(0xFF06070B),
            secondaryContainer = accentPalette.secondary.copy(alpha = 0.18f),
            onSecondaryContainer = TextPrimaryDark,
            tertiary = accentPalette.tertiary,
            onTertiary = Color(0xFF06070B),
            tertiaryContainer = accentPalette.tertiary.copy(alpha = 0.18f),
            onTertiaryContainer = TextPrimaryDark,
            background = ObsidianBlack,
            onBackground = TextPrimaryDark,
            surface = CharcoalSurface,
            onSurface = TextPrimaryDark,
            surfaceVariant = CharcoalElevated,
            onSurfaceVariant = TextSecondaryDark,
            outline = CyberBorderDim,
            error = CyberCrimson,
            onError = Color.White
        )
    } else {
        lightColorScheme(
            primary = accentPalette.primary,
            onPrimary = Color.White,
            primaryContainer = accentPalette.primary.copy(alpha = 0.14f),
            onPrimaryContainer = TextPrimaryLight,
            secondary = ElectricBlueDim,
            onSecondary = Color.White,
            secondaryContainer = ElectricBlueDim.copy(alpha = 0.14f),
            onSecondaryContainer = TextPrimaryLight,
            tertiary = RestrainedGreen,
            onTertiary = Color.White,
            background = CyberLightBg,
            onBackground = TextPrimaryLight,
            surface = CyberLightSurface,
            onSurface = TextPrimaryLight,
            surfaceVariant = CyberLightElevated,
            onSurfaceVariant = TextSecondaryLight,
            outline = Color(0xFFCBD5E1),
            error = CyberCrimson,
            onError = Color.White
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
