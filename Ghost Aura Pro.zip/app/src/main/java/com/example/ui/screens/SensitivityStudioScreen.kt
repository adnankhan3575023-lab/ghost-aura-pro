package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.DeviceProfileOption
import com.example.data.PresetJsonSerializer
import com.example.data.SensitivityPresetEntity
import com.example.ui.components.CyberGlassCard
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RestrainedGreen
import kotlin.math.roundToInt

@Composable
fun SensitivityStudioScreen(
    presets: List<SensitivityPresetEntity>,
    activePresetId: Long,
    onSavePreset: (SensitivityPresetEntity) -> Unit,
    onDuplicatePreset: (SensitivityPresetEntity) -> Unit,
    onDeletePreset: (SensitivityPresetEntity) -> Unit,
    onSelectActive: (Long) -> Unit,
    onResetSamples: () -> Unit,
    onImportJson: (String, (Boolean, String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var selectedCategoryFilter by remember { mutableStateOf("All") }
    val categories = listOf("All", "High", "Medium", "Low", "Custom")

    // Editor state
    var editingId by remember { mutableStateOf<Long?>(null) }
    var presetName by remember { mutableStateOf("Custom Tactical Ref") }
    var presetCategory by remember { mutableStateOf("High") }
    var generalVal by remember { mutableIntStateOf(165) }
    var redDotVal by remember { mutableIntStateOf(152) }
    var scope2xVal by remember { mutableIntStateOf(140) }
    var scope4xVal by remember { mutableIntStateOf(128) }
    var sniperVal by remember { mutableIntStateOf(85) }
    var freeLookVal by remember { mutableIntStateOf(145) }
    var deviceProfile by remember { mutableStateOf(DeviceProfileOption.STANDARD_GAMING_PHONE.label) }
    var screenNotes by remember { mutableStateOf(DeviceProfileOption.STANDARD_GAMING_PHONE.defaultScreenNote) }
    var refreshNotes by remember { mutableStateOf(DeviceProfileOption.STANDARD_GAMING_PHONE.defaultRefreshNote) }

    // Load active preset once when available
    var initializedFromActive by remember { mutableStateOf(false) }
    LaunchedEffect(presets, activePresetId) {
        if (!initializedFromActive && presets.isNotEmpty()) {
            val target = presets.find { it.id == activePresetId } ?: presets.first()
            editingId = target.id
            presetName = target.name
            presetCategory = target.category
            generalVal = target.general
            redDotVal = target.redDot
            scope2xVal = target.scope2x
            scope4xVal = target.scope4x
            sniperVal = target.sniperScope
            freeLookVal = target.freeLook
            deviceProfile = target.deviceProfile
            screenNotes = target.screenSizeNotes
            refreshNotes = target.refreshRateNotes
            initializedFromActive = true
        }
    }

    // Dialog states
    var showCompareDialog by remember { mutableStateOf(false) }
    var compareLeftId by remember { mutableStateOf<Long?>(null) }
    var compareRightId by remember { mutableStateOf<Long?>(null) }

    var showJsonDialog by remember { mutableStateOf(false) }
    var jsonInputText by remember { mutableStateOf("") }
    var jsonFeedbackMessage by remember { mutableStateOf<String?>(null) }

    var renameTarget by remember { mutableStateOf<SensitivityPresetEntity?>(null) }
    var renameText by remember { mutableStateOf("") }

    val filteredPresets = remember(presets, selectedCategoryFilter) {
        if (selectedCategoryFilter == "All") presets
        else presets.filter { it.category.equals(selectedCategoryFilter, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("sensitivity_studio_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Honest Reference Disclaimer Banner
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CyberAmber.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberAmber.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Sensitivity reference disclaimer",
                        tint = CyberAmber,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = stringResource(id = R.string.sensitivity_disclaimer),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // 2. Top Action Bar: Compare, JSON Import/Export, Reset Samples
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        compareLeftId = presets.firstOrNull()?.id
                        compareRightId = presets.getOrNull(1)?.id ?: presets.firstOrNull()?.id
                        showCompareDialog = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("compare_presets_button")
                ) {
                    Icon(Icons.Default.CompareArrows, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Compare", style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = {
                        jsonInputText = PresetJsonSerializer.exportSensitivityPresetsToJson(presets)
                        jsonFeedbackMessage = null
                        showJsonDialog = true
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("json_import_export_button")
                ) {
                    Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("JSON I/O", style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = onResetSamples,
                    modifier = Modifier.testTag("reset_sensitivity_samples_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset samples", modifier = Modifier.size(16.dp))
                }
            }
        }

        // 3. Live Sensitivity Reference Editor Card
        item {
            CyberGlassCard(accentColor = NeonPurple) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SENSITIVITY REFERENCE EDITOR",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Suggested manual reference values (0 - 200 scale)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = NeonPurple.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = presetCategory.uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonPurple,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = presetName,
                    onValueChange = { presetName = it.take(40) },
                    label = { Text("Preset Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("sensitivity_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Preset Category Selector (High / Medium / Low / Custom)
                Text("Category Tier:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("High", "Medium", "Low", "Custom")) { cat ->
                        FilterChip(
                            selected = presetCategory.equals(cat, ignoreCase = true),
                            onClick = {
                                presetCategory = cat
                                when (cat) {
                                    "High" -> {
                                        generalVal = 180; redDotVal = 166; scope2xVal = 154; scope4xVal = 140; sniperVal = 92; freeLookVal = 158
                                    }
                                    "Medium" -> {
                                        generalVal = 146; redDotVal = 135; scope2xVal = 126; scope4xVal = 116; sniperVal = 76; freeLookVal = 130
                                    }
                                    "Low" -> {
                                        generalVal = 110; redDotVal = 102; scope2xVal = 94; scope4xVal = 86; sniperVal = 60; freeLookVal = 100
                                    }
                                }
                            },
                            label = { Text(cat) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Device Profile Selector
                Text("Device Profile & Form Factor:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(DeviceProfileOption.entries) { option ->
                        FilterChip(
                            selected = deviceProfile == option.label,
                            onClick = {
                                deviceProfile = option.label
                                screenNotes = option.defaultScreenNote
                                refreshNotes = option.defaultRefreshNote
                            },
                            label = { Text(option.label) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 6 Sensitivity Sliders + Steppers
                SensitivityChannelRow("General Sensitivity", generalVal, NeonPurple) { generalVal = it }
                SensitivityChannelRow("Red Dot Sight", redDotVal, ElectricBlue) { redDotVal = it }
                SensitivityChannelRow("2x Scope", scope2xVal, RestrainedGreen) { scope2xVal = it }
                SensitivityChannelRow("4x Scope", scope4xVal, NeonPurple) { scope4xVal = it }
                SensitivityChannelRow("Sniper Scope (AWM)", sniperVal, CyberAmber) { sniperVal = it }
                SensitivityChannelRow("Free Look (360° Eye)", freeLookVal, ElectricBlue) { freeLookVal = it }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = screenNotes,
                    onValueChange = { screenNotes = it.take(140) },
                    label = { Text("Screen-Size Reference Note") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = refreshNotes,
                    onValueChange = { refreshNotes = it.take(140) },
                    label = { Text("Refresh-Rate & Touch Pacing Note") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            onSavePreset(
                                SensitivityPresetEntity(
                                    id = editingId ?: 0L,
                                    name = presetName.ifBlank { "Custom Preset" },
                                    category = presetCategory,
                                    general = generalVal,
                                    redDot = redDotVal,
                                    scope2x = scope2xVal,
                                    scope4x = scope4xVal,
                                    sniperScope = sniperVal,
                                    freeLook = freeLookVal,
                                    deviceProfile = deviceProfile,
                                    screenSizeNotes = screenNotes,
                                    refreshRateNotes = refreshNotes,
                                    isSample = false
                                )
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_sensitivity_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save / Update")
                    }

                    OutlinedButton(
                        onClick = {
                            val newEntity = SensitivityPresetEntity(
                                id = 0L,
                                name = "${presetName.ifBlank { "Preset" }} #${presets.size + 1}",
                                category = presetCategory,
                                general = generalVal,
                                redDot = redDotVal,
                                scope2x = scope2xVal,
                                scope4x = scope4xVal,
                                sniperScope = sniperVal,
                                freeLook = freeLookVal,
                                deviceProfile = deviceProfile,
                                screenSizeNotes = screenNotes,
                                refreshRateNotes = refreshNotes,
                                isSample = false
                            )
                            onSavePreset(newEntity)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_new_sensitivity_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save as New")
                    }
                }
            }
        }

        // 4. Category Filter Bar for Saved Presets
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SAVED REFERENCE PRESETS (${filteredPresets.size})",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategoryFilter == cat,
                        onClick = { selectedCategoryFilter = cat },
                        label = { Text(cat) }
                    )
                }
            }
        }

        // 5. Saved Presets List
        items(filteredPresets, key = { it.id }) { preset ->
            val isSelected = preset.id == activePresetId
            CyberGlassCard(
                accentColor = if (isSelected) RestrainedGreen else NeonPurple,
                onClick = {
                    editingId = preset.id
                    presetName = preset.name
                    presetCategory = preset.category
                    generalVal = preset.general
                    redDotVal = preset.redDot
                    scope2xVal = preset.scope2x
                    scope4xVal = preset.scope4x
                    sniperVal = preset.sniperScope
                    freeLookVal = preset.freeLook
                    deviceProfile = preset.deviceProfile
                    screenNotes = preset.screenSizeNotes
                    refreshNotes = preset.refreshRateNotes
                    onSelectActive(preset.id)
                }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = preset.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (preset.isSample) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = ElectricBlue.copy(alpha = 0.16f)
                                ) {
                                    Text(
                                        text = "SAMPLE SUGGESTION",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ElectricBlue,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = "${preset.category} Tier • ${preset.deviceProfile}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    Row {
                        IconButton(onClick = {
                            renameTarget = preset
                            renameText = preset.name
                        }) {
                            Icon(Icons.Default.Edit, contentDescription = "Rename preset", tint = ElectricBlue)
                        }
                        IconButton(onClick = { onDuplicatePreset(preset) }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate preset", tint = NeonPurple)
                        }
                        IconButton(onClick = { onDeletePreset(preset) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete preset", tint = CyberCrimson)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 6-Pill Reference Values Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MiniRefBadge("GEN", preset.general)
                    MiniRefBadge("RED", preset.redDot)
                    MiniRefBadge("2X", preset.scope2x)
                    MiniRefBadge("4X", preset.scope4x)
                    MiniRefBadge("AWM", preset.sniperScope)
                    MiniRefBadge("LOOK", preset.freeLook)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Screen: ${preset.screenSizeNotes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Refresh: ${preset.refreshRateNotes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    // Rename Dialog
    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Sensitivity Preset") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it.take(40) },
                    label = { Text("New Preset Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (renameText.isNotBlank()) {
                        onSavePreset(target.copy(name = renameText.trim()))
                    }
                    renameTarget = null
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Side-by-Side Comparison Dialog
    if (showCompareDialog && presets.isNotEmpty()) {
        val leftPreset = presets.find { it.id == compareLeftId } ?: presets.first()
        val rightPreset = presets.find { it.id == compareRightId } ?: presets.last()

        AlertDialog(
            onDismissRequest = { showCompareDialog = false },
            title = { Text("Side-by-Side Preset Comparison") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tap a preset chip to switch A or B:", style = MaterialTheme.typography.bodySmall)
                    Text("Preset A (Left):", style = MaterialTheme.typography.labelSmall, color = NeonPurple)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(presets) { p ->
                            FilterChip(
                                selected = p.id == leftPreset.id,
                                onClick = { compareLeftId = p.id },
                                label = { Text(p.name.take(14)) }
                            )
                        }
                    }
                    Text("Preset B (Right):", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(presets) { p ->
                            FilterChip(
                                selected = p.id == rightPreset.id,
                                onClick = { compareRightId = p.id },
                                label = { Text(p.name.take(14)) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    CompareMetricRow("General", leftPreset.general, rightPreset.general)
                    CompareMetricRow("Red Dot", leftPreset.redDot, rightPreset.redDot)
                    CompareMetricRow("2x Scope", leftPreset.scope2x, rightPreset.scope2x)
                    CompareMetricRow("4x Scope", leftPreset.scope4x, rightPreset.scope4x)
                    CompareMetricRow("Sniper", leftPreset.sniperScope, rightPreset.sniperScope)
                    CompareMetricRow("Free Look", leftPreset.freeLook, rightPreset.freeLook)
                }
            },
            confirmButton = {
                TextButton(onClick = { showCompareDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // JSON Import / Export Modal
    if (showJsonDialog) {
        AlertDialog(
            onDismissRequest = { showJsonDialog = false },
            title = { Text("JSON Preset Import & Export") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Copy exported JSON to share or back up your presets, or paste valid preset JSON below and tap Import.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = jsonInputText,
                        onValueChange = { jsonInputText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .testTag("json_io_textfield"),
                        textStyle = MaterialTheme.typography.labelSmall
                    )
                    jsonFeedbackMessage?.let { msg ->
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricBlue
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(jsonInputText))
                                jsonFeedbackMessage = "Copied JSON to clipboard."
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy")
                        }
                        OutlinedButton(
                            onClick = {
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/json"
                                    putExtra(Intent.EXTRA_TEXT, jsonInputText)
                                    putExtra(Intent.EXTRA_SUBJECT, "Ghost Aura Sensitivity Presets JSON")
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share Presets JSON"))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share")
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onImportJson(jsonInputText) { ok, msg ->
                            jsonFeedbackMessage = msg
                            if (ok) showJsonDialog = false
                        }
                    }
                ) {
                    Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Import JSON")
                }
            },
            dismissButton = {
                TextButton(onClick = { showJsonDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun SensitivityChannelRow(
    label: String,
    value: Int,
    accent: Color,
    onValueChange: (Int) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .size(28.dp)
                        .clickable { onValueChange((value - 1).coerceIn(0, 200)) }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease $label", modifier = Modifier.size(16.dp))
                    }
                }
                Text(
                    text = value.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    color = accent,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .size(28.dp)
                        .clickable { onValueChange((value + 1).coerceIn(0, 200)) }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Add, contentDescription = "Increase $label", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.roundToInt().coerceIn(0, 200)) },
            valueRange = 0f..200f,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent
            )
        )
    }
}

@Composable
private fun MiniRefBadge(label: String, value: Int) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value.toString(), style = MaterialTheme.typography.labelLarge, color = ElectricBlue, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CompareMetricRow(label: String, leftVal: Int, rightVal: Int) {
    val diff = rightVal - leftVal
    val diffLabel = when {
        diff > 0 -> "+$diff"
        diff < 0 -> "$diff"
        else -> "0"
    }
    val diffColor = when {
        diff > 0 -> RestrainedGreen
        diff < 0 -> CyberAmber
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "$leftVal", style = MaterialTheme.typography.labelLarge, color = NeonPurple)
            Text(text = "$label (Δ $diffLabel)", style = MaterialTheme.typography.labelSmall, color = diffColor)
            Text(text = "$rightVal", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LinearProgressIndicator(
                progress = { (leftVal / 200f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .weight(1f)
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = NeonPurple
            )
            LinearProgressIndicator(
                progress = { (rightVal / 200f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .weight(1f)
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = ElectricBlue
            )
        }
    }
}
