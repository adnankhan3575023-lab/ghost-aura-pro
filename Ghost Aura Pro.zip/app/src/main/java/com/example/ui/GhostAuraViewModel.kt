package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CrosshairPresetEntity
import com.example.data.CrosshairStyle
import com.example.data.DeviceProfileOption
import com.example.data.GhostAuraDatabase
import com.example.data.GhostAuraRepository
import com.example.data.PresetJsonSerializer
import com.example.data.SensitivityPresetEntity
import com.example.data.UserPreferencesRepository
import com.example.data.UserSettingsState
import com.example.monitoring.AppIntegrityReport
import com.example.monitoring.DeviceTelemetryMonitor
import com.example.monitoring.LatencyTestResult
import com.example.monitoring.ReadinessCheckItem
import com.example.monitoring.TelemetrySnapshot
import com.example.overlay.FloatingHudService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LiveCrosshairEditorState(
    val editingPresetId: Long? = null,
    val name: String = "Cyan Cyber Cross",
    val styleIndex: Int = CrosshairStyle.DOT_PRECISION.index,
    val sizeDp: Float = 24f,
    val thicknessDp: Float = 2.2f,
    val gapDp: Float = 5f,
    val showCenterDot: Boolean = true,
    val showOutline: Boolean = true,
    val colorHex: String = "#00F0FF",
    val opacity: Float = 0.95f,
    val rotationDeg: Float = 0f,
    val backgroundSceneIndex: Int = 0, // 0 = Tactical Range, 1 = Cyber Grid, 2 = Dusk Urban, 3 = High Contrast Day
    val movingTargetDemo: Boolean = true
)

class GhostAuraViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext: Context = application.applicationContext
    private val database = GhostAuraDatabase.getInstance(appContext)
    private val repository = GhostAuraRepository(database.dao())
    private val prefsRepository = UserPreferencesRepository(appContext)
    val telemetryMonitor = DeviceTelemetryMonitor(appContext)

    val settingsState: StateFlow<UserSettingsState> = prefsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettingsState())

    val sensitivityPresets: StateFlow<List<SensitivityPresetEntity>> = repository.sensitivityPresets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val crosshairPresets: StateFlow<List<CrosshairPresetEntity>> = repository.crosshairPresets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _telemetrySnapshot = MutableStateFlow(TelemetrySnapshot())
    val telemetrySnapshot: StateFlow<TelemetrySnapshot> = _telemetrySnapshot.asStateFlow()

    private val _ramHistory = MutableStateFlow<List<Float>>(emptyList())
    val ramHistory: StateFlow<List<Float>> = _ramHistory.asStateFlow()

    private val _batteryTempHistory = MutableStateFlow<List<Float>>(emptyList())
    val batteryTempHistory: StateFlow<List<Float>> = _batteryTempHistory.asStateFlow()

    private val _framePacingHistory = MutableStateFlow<List<Float>>(emptyList())
    val framePacingHistory: StateFlow<List<Float>> = _framePacingHistory.asStateFlow()

    private val _readinessChecks = MutableStateFlow<List<ReadinessCheckItem>>(emptyList())
    val readinessChecks: StateFlow<List<ReadinessCheckItem>> = _readinessChecks.asStateFlow()

    private val _isMonitoringPaused = MutableStateFlow(false)
    val isMonitoringPaused: StateFlow<Boolean> = _isMonitoringPaused.asStateFlow()

    private val _latencyTestResult = MutableStateFlow<LatencyTestResult?>(null)
    val latencyTestResult: StateFlow<LatencyTestResult?> = _latencyTestResult.asStateFlow()

    private val _isLatencyTesting = MutableStateFlow(false)
    val isLatencyTesting: StateFlow<Boolean> = _isLatencyTesting.asStateFlow()

    private val _crosshairEditor = MutableStateFlow(LiveCrosshairEditorState())
    val crosshairEditor: StateFlow<LiveCrosshairEditorState> = _crosshairEditor.asStateFlow()

    private val _inAppFloatingPreviewEnabled = MutableStateFlow(false)
    val inAppFloatingPreviewEnabled: StateFlow<Boolean> = _inAppFloatingPreviewEnabled.asStateFlow()

    private val _systemOverlayActive = MutableStateFlow(false)
    val systemOverlayActive: StateFlow<Boolean> = _systemOverlayActive.asStateFlow()

    private val _crosshairOverlayActive = MutableStateFlow(false)
    val crosshairOverlayActive: StateFlow<Boolean> = _crosshairOverlayActive.asStateFlow()

    private val _terminalLogs = MutableStateFlow<List<String>>(emptyList())
    val terminalLogs: StateFlow<List<String>> = _terminalLogs.asStateFlow()

    private val _isVisualDemoScanning = MutableStateFlow(false)
    val isVisualDemoScanning: StateFlow<Boolean> = _isVisualDemoScanning.asStateFlow()

    private val _visualDemoProgress = MutableStateFlow(0f)
    val visualDemoProgress: StateFlow<Float> = _visualDemoProgress.asStateFlow()

    private val _integrityReport = MutableStateFlow<AppIntegrityReport?>(null)
    val integrityReport: StateFlow<AppIntegrityReport?> = _integrityReport.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    private var monitoringJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
        telemetryMonitor.startUiFramePacingObserver()
        refreshIntegrityReport()
        appendTerminalLog("BOOT // Ghost Aura Pro v1.0 kernel telemetry initialized.")
        appendTerminalLog("SANDBOX // Local-only storage verified. Zero external game hooking.")
        startMonitoringLoop()
    }

    private fun startMonitoringLoop() {
        monitoringJob?.cancel()
        monitoringJob = viewModelScope.launch {
            while (isActive) {
                if (!_isMonitoringPaused.value) {
                    sampleTelemetryNow()
                }
                val interval = settingsState.value.monitoringIntervalMs.coerceIn(500L, 10000L)
                delay(interval)
            }
        }
    }

    fun sampleTelemetryNow() {
        val snap = telemetryMonitor.sampleSnapshot()
        _telemetrySnapshot.value = snap
        _ramHistory.value = (_ramHistory.value + snap.ramUsagePercent).takeLast(24)
        snap.batteryTempCelsius?.let { temp ->
            _batteryTempHistory.value = (_batteryTempHistory.value + temp).takeLast(24)
        }
        _framePacingHistory.value = (_framePacingHistory.value + snap.localUiFramePacingFps).takeLast(24)
        _readinessChecks.value = telemetryMonitor.evaluateGamingReadiness(snap)
        _systemOverlayActive.value = FloatingHudService.isRunning
    }

    fun toggleMonitoringPaused() {
        triggerFeedback()
        val next = !_isMonitoringPaused.value
        _isMonitoringPaused.value = next
        appendTerminalLog(if (next) "MONITOR // Telemetry sampling paused by user." else "MONITOR // Telemetry sampling resumed.")
    }

    fun refreshIntegrityReport() {
        _integrityReport.value = telemetryMonitor.inspectAppIntegrity()
        _systemOverlayActive.value = FloatingHudService.isRunning
    }

    fun runLatencyCheck(endpointUrl: String) {
        if (_isLatencyTesting.value) return
        triggerFeedback()
        viewModelScope.launch {
            _isLatencyTesting.value = true
            appendTerminalLog("NET_PING // Probing authorized endpoint: $endpointUrl")
            val result = telemetryMonitor.runAuthorizedLatencyTest(endpointUrl)
            _latencyTestResult.value = result
            _isLatencyTesting.value = false
            if (result.success) {
                appendTerminalLog("NET_PING // RTT avg=${result.avgMs}ms min=${result.minMs}ms jitter=${result.jitterMs}ms")
            } else {
                appendTerminalLog("NET_PING // Warning: ${result.errorMessage}")
            }
        }
    }

    fun runVisualDemoDiagnosticSweep() {
        if (_isVisualDemoScanning.value) return
        triggerFeedback()
        viewModelScope.launch {
            _isVisualDemoScanning.value = true
            _visualDemoProgress.value = 0f
            appendTerminalLog("VISUAL_DEMO // Starting animated local hardware & permission sweep...")
            val steps = listOf(
                0.20f to "VISUAL_DEMO // [1/5] Inspecting ActivityManager RAM allocations...",
                0.45f to "VISUAL_DEMO // [2/5] Querying BatteryManager thermal & voltage sensors...",
                0.68f to "VISUAL_DEMO // [3/5] Verifying StatFs internal flash blocks...",
                0.88f to "VISUAL_DEMO // [4/5] Auditing APK SHA-256 signature & OS sandbox flags...",
                1.00f to "VISUAL_DEMO // [5/5] Sweep complete. All local modules nominal."
            )
            for ((prog, msg) in steps) {
                delay(320L)
                _visualDemoProgress.value = prog
                appendTerminalLog(msg)
            }
            refreshIntegrityReport()
            sampleTelemetryNow()
            delay(400L)
            _isVisualDemoScanning.value = false
        }
    }

    // --- Sensitivity Studio Operations ---
    fun saveSensitivityPreset(preset: SensitivityPresetEntity) {
        triggerFeedback()
        viewModelScope.launch {
            val id = repository.saveSensitivityPreset(preset)
            prefsRepository.setActiveSensitivityPreset(id)
            postBanner("Saved sensitivity preset '${preset.name}'")
            appendTerminalLog("SENS_STUDIO // Saved preset '${preset.name}' (${preset.category}).")
        }
    }

    fun duplicateSensitivityPreset(preset: SensitivityPresetEntity) {
        triggerFeedback()
        viewModelScope.launch {
            val copy = preset.copy(
                id = 0L,
                name = "${preset.name} (Copy)",
                isSample = false,
                updatedAt = System.currentTimeMillis()
            )
            repository.saveSensitivityPreset(copy)
            postBanner("Duplicated '${preset.name}'")
        }
    }

    fun deleteSensitivityPreset(preset: SensitivityPresetEntity) {
        triggerFeedback()
        viewModelScope.launch {
            repository.deleteSensitivityPreset(preset.id)
            postBanner("Deleted '${preset.name}'")
        }
    }

    fun selectActiveSensitivityPreset(id: Long) {
        triggerFeedback()
        viewModelScope.launch {
            prefsRepository.setActiveSensitivityPreset(id)
            postBanner("Selected active reference preset")
        }
    }

    fun resetSensitivitySamples() {
        triggerFeedback()
        viewModelScope.launch {
            repository.resetSensitivitySamples()
            postBanner("Restored default sample sensitivity presets")
            appendTerminalLog("SENS_STUDIO // Restored default sample sensitivity presets.")
        }
    }

    fun importSensitivityJson(rawJson: String, onResult: (Boolean, String) -> Unit) {
        triggerFeedback()
        val parsedResult = PresetJsonSerializer.parseSensitivityPresetsFromJson(rawJson)
        parsedResult.onSuccess { list ->
            viewModelScope.launch {
                list.forEach { repository.saveSensitivityPreset(it) }
                val msg = "Successfully imported ${list.size} sensitivity preset(s)."
                postBanner(msg)
                appendTerminalLog("SENS_STUDIO // $msg")
                onResult(true, msg)
            }
        }.onFailure { err ->
            val msg = "Invalid JSON: ${err.localizedMessage ?: "Parse error"}"
            onResult(false, msg)
        }
    }

    // --- Crosshair Designer Operations ---
    fun loadCrosshairIntoEditor(preset: CrosshairPresetEntity) {
        triggerFeedback()
        _crosshairEditor.value = _crosshairEditor.value.copy(
            editingPresetId = preset.id,
            name = preset.name,
            styleIndex = preset.styleIndex,
            sizeDp = preset.sizeDp,
            thicknessDp = preset.thicknessDp,
            gapDp = preset.gapDp,
            showCenterDot = preset.showCenterDot,
            showOutline = preset.showOutline,
            colorHex = preset.colorHex,
            opacity = preset.opacity,
            rotationDeg = preset.rotationDeg
        )
        viewModelScope.launch {
            prefsRepository.setActiveCrosshairPreset(preset.id)
        }
    }

    fun updateCrosshairEditor(transform: (LiveCrosshairEditorState) -> LiveCrosshairEditorState) {
        _crosshairEditor.value = transform(_crosshairEditor.value)
        if (_systemOverlayActive.value && _crosshairOverlayActive.value) {
            syncSystemOverlayService(showReticle = true)
        }
    }

    fun saveCurrentCrosshairAsPreset(customName: String, saveAsNew: Boolean) {
        triggerFeedback()
        val editor = _crosshairEditor.value
        val cleanName = customName.trim().ifBlank { "Custom Reticle" }.take(36)
        viewModelScope.launch {
            val entity = CrosshairPresetEntity(
                id = if (saveAsNew) 0L else (editor.editingPresetId ?: 0L),
                name = cleanName,
                styleIndex = editor.styleIndex,
                sizeDp = editor.sizeDp,
                thicknessDp = editor.thicknessDp,
                gapDp = editor.gapDp,
                showCenterDot = editor.showCenterDot,
                showOutline = editor.showOutline,
                colorHex = editor.colorHex,
                opacity = editor.opacity,
                rotationDeg = editor.rotationDeg,
                isDefault = false
            )
            val savedId = repository.saveCrosshairPreset(entity)
            _crosshairEditor.value = editor.copy(editingPresetId = savedId, name = cleanName)
            prefsRepository.setActiveCrosshairPreset(savedId)
            postBanner("Saved crosshair preset '$cleanName'")
            appendTerminalLog("RETICLE_STUDIO // Saved crosshair preset '$cleanName'.")
        }
    }

    fun duplicateCrosshairPreset(preset: CrosshairPresetEntity) {
        triggerFeedback()
        viewModelScope.launch {
            repository.saveCrosshairPreset(
                preset.copy(
                    id = 0L,
                    name = "${preset.name} (Copy)",
                    isDefault = false
                )
            )
            postBanner("Duplicated '${preset.name}'")
        }
    }

    fun deleteCrosshairPreset(preset: CrosshairPresetEntity) {
        triggerFeedback()
        viewModelScope.launch {
            repository.deleteCrosshairPreset(preset.id)
            postBanner("Deleted '${preset.name}'")
        }
    }

    fun restoreDefaultCrosshairs() {
        triggerFeedback()
        viewModelScope.launch {
            repository.resetCrosshairDefaults()
            val def = GhostAuraRepository.defaultCrosshairSamples().first()
            _crosshairEditor.value = LiveCrosshairEditorState(
                name = def.name,
                styleIndex = def.styleIndex,
                sizeDp = def.sizeDp,
                thicknessDp = def.thicknessDp,
                gapDp = def.gapDp,
                showCenterDot = def.showCenterDot,
                showOutline = def.showOutline,
                colorHex = def.colorHex,
                opacity = def.opacity,
                rotationDeg = def.rotationDeg
            )
            postBanner("Restored default crosshair presets")
        }
    }

    // --- Floating Quick-Access Widget & Overlay Control ---
    fun toggleInAppFloatingPreview(enabled: Boolean) {
        triggerFeedback()
        _inAppFloatingPreviewEnabled.value = enabled
    }

    fun canDrawSystemOverlays(): Boolean = Settings.canDrawOverlays(appContext)

    fun startOrUpdateSystemOverlay(showReticle: Boolean = _crosshairOverlayActive.value) {
        triggerFeedback()
        if (!Settings.canDrawOverlays(appContext)) {
            postBanner("Overlay permission required first.")
            return
        }
        _crosshairOverlayActive.value = showReticle
        syncSystemOverlayService(showReticle)
        _systemOverlayActive.value = true
        appendTerminalLog("HUD_OVERLAY // Started user-consented floating HUD service.")
        postBanner("Floating Quick-Access HUD active")
    }

    private fun syncSystemOverlayService(showReticle: Boolean) {
        val prefs = settingsState.value
        val activeSens = sensitivityPresets.value.find { it.id == prefs.activeSensitivityId }
            ?: sensitivityPresets.value.firstOrNull()
        val sensSummary = if (activeSens != null) {
            "${activeSens.name}: Gen ${activeSens.general} | Red ${activeSens.redDot} | 2x ${activeSens.scope2x} | 4x ${activeSens.scope4x}"
        } else {
            "Gen 148 | Red 136 | 2x 128 | 4x 118"
        }
        val editor = _crosshairEditor.value

        val intent = Intent(appContext, FloatingHudService::class.java).apply {
            putExtra(FloatingHudService.EXTRA_BUBBLE_SIZE_DP, prefs.floatingBubbleSizeDp)
            putExtra(FloatingHudService.EXTRA_BUBBLE_ALPHA, prefs.floatingBubbleOpacity)
            putExtra(FloatingHudService.EXTRA_BUBBLE_COLOR, prefs.floatingBubbleColorHex)
            putExtra(FloatingHudService.EXTRA_PRESET_SUMMARY, sensSummary)
            putExtra(FloatingHudService.EXTRA_SHOW_RETICLE, showReticle)

            putExtra(FloatingHudService.EXTRA_RETICLE_STYLE, editor.styleIndex)
            putExtra(FloatingHudService.EXTRA_RETICLE_SIZE, editor.sizeDp)
            putExtra(FloatingHudService.EXTRA_RETICLE_THICKNESS, editor.thicknessDp)
            putExtra(FloatingHudService.EXTRA_RETICLE_GAP, editor.gapDp)
            putExtra(FloatingHudService.EXTRA_RETICLE_DOT, editor.showCenterDot)
            putExtra(FloatingHudService.EXTRA_RETICLE_OUTLINE, editor.showOutline)
            putExtra(FloatingHudService.EXTRA_RETICLE_COLOR, editor.colorHex)
            putExtra(FloatingHudService.EXTRA_RETICLE_OPACITY, editor.opacity)
            putExtra(FloatingHudService.EXTRA_RETICLE_ROTATION, editor.rotationDeg)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(intent)
            } else {
                appContext.startService(intent)
            }
        }
    }

    fun stopSystemOverlay() {
        triggerFeedback()
        val stopIntent = Intent(appContext, FloatingHudService::class.java).apply {
            action = FloatingHudService.ACTION_STOP_OVERLAY
        }
        runCatching { appContext.startService(stopIntent) }
        _systemOverlayActive.value = false
        _crosshairOverlayActive.value = false
        appendTerminalLog("HUD_OVERLAY // Floating overlay service stopped by user.")
        postBanner("Floating HUD stopped")
    }

    // --- Settings & Personalization ---
    fun setThemeMode(modeId: Int) {
        triggerFeedback()
        viewModelScope.launch { prefsRepository.updateThemeMode(modeId) }
    }

    fun setAccentPalette(paletteId: Int) {
        triggerFeedback()
        viewModelScope.launch { prefsRepository.updateAccentPalette(paletteId) }
    }

    fun setLanguage(code: String) {
        triggerFeedback()
        viewModelScope.launch {
            prefsRepository.updateLanguage(code)
            postBanner("Language updated to ${code.uppercase()}")
        }
    }

    fun setHapticEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.updateHaptic(enabled) }
    }

    fun setSoundEffectsEnabled(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.updateSoundEffects(enabled) }
    }

    fun setAnimationIntensity(intensity: Float) {
        viewModelScope.launch { prefsRepository.updateAnimationIntensity(intensity) }
    }

    fun setMonitoringInterval(intervalMs: Long) {
        triggerFeedback()
        viewModelScope.launch {
            prefsRepository.updateMonitoringInterval(intervalMs)
            appendTerminalLog("CONFIG // Telemetry interval updated to ${intervalMs}ms.")
        }
    }

    fun updateBubbleAppearance(sizeDp: Int, opacity: Float, colorHex: String) {
        viewModelScope.launch {
            prefsRepository.updateFloatingBubbleConfig(sizeDp, opacity, colorHex)
            if (_systemOverlayActive.value) {
                syncSystemOverlayService(_crosshairOverlayActive.value)
            }
        }
    }

    fun setAdConsent(consent: Boolean) {
        triggerFeedback()
        viewModelScope.launch { prefsRepository.updateAdConsent(consent) }
    }

    fun resetAllPreferences() {
        triggerFeedback()
        viewModelScope.launch {
            prefsRepository.resetAllSettings()
            postBanner("All app preferences reset to defaults")
            appendTerminalLog("CONFIG // Preferences reset to factory defaults.")
        }
    }

    fun clearBanner() {
        _statusBannerMessage.value = null
    }

    fun postBanner(message: String) {
        _statusBannerMessage.value = message
    }

    private fun appendTerminalLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val next = (_terminalLogs.value + "[$time] $message").takeLast(45)
        _terminalLogs.value = next
    }

    fun triggerFeedback() {
        val prefs = settingsState.value
        if (prefs.hapticEnabled) {
            runCatching {
                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                    vm?.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(18L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(18L)
                }
            }
        }
        if (prefs.soundEffectsEnabled) {
            runCatching {
                val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 25)
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 28)
            }
        }
    }

    override fun onCleared() {
        telemetryMonitor.stopUiFramePacingObserver()
        super.onCleared()
    }
}
