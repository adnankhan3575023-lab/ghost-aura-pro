package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.PresetJsonSerializer
import com.example.data.UserSettingsState
import com.example.monitoring.AppIntegrityReport
import com.example.ui.components.CyberGlassCard
import com.example.ui.theme.AccentPalette
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RestrainedGreen
import kotlin.math.roundToInt

private val SUPPORTED_LANGUAGES = listOf(
    "en" to "English",
    "es" to "Español",
    "pt" to "Português",
    "id" to "Indonesia",
    "hi" to "हिन्दी"
)

@Composable
fun CyberTerminalSettingsScreen(
    terminalLogs: List<String>,
    isVisualDemoScanning: Boolean,
    visualDemoProgress: Float,
    integrityReport: AppIntegrityReport?,
    settings: UserSettingsState,
    sensitivityCount: Int,
    crosshairCount: Int,
    onRunVisualDemoSweep: () -> Unit,
    onRefreshIntegrity: () -> Unit,
    onSelectThemeMode: (Int) -> Unit,
    onSelectAccentPalette: (Int) -> Unit,
    onSelectLanguage: (String) -> Unit,
    onToggleHaptic: (Boolean) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onChangeAnimationIntensity: (Float) -> Unit,
    onChangeMonitoringInterval: (Long) -> Unit,
    onToggleAdConsent: (Boolean) -> Unit,
    onResetSettings: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var subTabIndex by remember { mutableIntStateOf(0) }
    val subTabs = listOf("Cyber Deck", "Settings", "Pro & Privacy")

    var showExportSettingsDialog by remember { mutableStateOf(false) }
    var exportedSettingsJson by remember { mutableStateOf("") }
    var showPrivacyModal by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("cyber_terminal_settings_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Sub-navigation segmented bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                subTabs.forEachIndexed { idx, title ->
                    val selected = subTabIndex == idx
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { subTabIndex = idx }
                            .testTag("cyber_subtab_$idx")
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        when (subTabIndex) {
            0 -> {
                // --- SUB-TAB 0: CYBER SECURITY & DIAGNOSTICS TERMINAL ---
                item {
                    CyberGlassCard(accentColor = RestrainedGreen, glowStrength = 0.65f) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Terminal, contentDescription = null, tint = RestrainedGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "CYBER DIAGNOSTICS TERMINAL",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = RestrainedGreen
                                    )
                                    Text(
                                        text = "Local sandbox audit & system telemetry log",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = CyberAmber.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CyberAmber)
                            ) {
                                Text(
                                    text = "VISUAL DEMO",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyberAmber,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Terminal Console Output Box
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF05070B))
                                .border(1.dp, RestrainedGreen.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            terminalLogs.takeLast(9).forEach { logLine ->
                                Text(
                                    text = "> $logLine",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (logLine.contains("VISUAL_DEMO")) ElectricBlue else RestrainedGreen
                                )
                            }
                        }

                        if (isVisualDemoScanning) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Visual Demo — Animated Diagnostic Sweep Active",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CyberAmber
                                )
                                Text(
                                    text = "${(visualDemoProgress * 100).roundToInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricBlue
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { visualDemoProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = ElectricBlue
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = onRunVisualDemoSweep,
                            enabled = !isVisualDemoScanning,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("visual_demo_scan_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = RestrainedGreen)
                        ) {
                            Icon(Icons.Default.Radar, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isVisualDemoScanning) "Running Visual Demo Sweep..." else "Run Diagnostic Animation (Visual Demo)",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // App Integrity Verification Card
                item {
                    CyberGlassCard(accentColor = ElectricBlue) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.GppGood, contentDescription = null, tint = ElectricBlue)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "THIS APP INTEGRITY & SANDBOX AUDIT",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ElectricBlue,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            TextButton(onClick = onRefreshIntegrity) {
                                Text("Refresh", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        integrityReport?.let { rep ->
                            AuditKeyValueRow("Package ID", rep.packageName)
                            AuditKeyValueRow("Version", rep.versionName)
                            AuditKeyValueRow("Signing Cert (SHA-256)", rep.signatureSha256)
                            AuditKeyValueRow("Installer Source", rep.installerSource)
                            AuditKeyValueRow("Build Mode", if (rep.isDebugBuild) "Debug / Development" else "Release Signed")
                            AuditKeyValueRow("Game Memory Access", "Disabled (Strict OS Sandbox)")
                        }
                    }
                }

                // Permission Status & Explanation Matrix
                item {
                    CyberGlassCard(accentColor = NeonPurple) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = NeonPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PERMISSION TRANSPARENCY & SHORTCUTS",
                                style = MaterialTheme.typography.titleMedium,
                                color = NeonPurple,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        PermissionAuditRow(
                            name = "Display Over Other Apps (SYSTEM_ALERT_WINDOW)",
                            granted = integrityReport?.overlayPermissionGranted == true,
                            explanation = "Optional. Used only when you explicitly enable the movable Floating Quick-Access Bubble or visual Crosshair Overlay.",
                            onManageClick = {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                runCatching { context.startActivity(intent) }
                            }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        PermissionAuditRow(
                            name = "Network & Connectivity (INTERNET / ACCESS_NETWORK_STATE)",
                            granted = integrityReport?.networkStateGranted == true,
                            explanation = "Used to detect Wi-Fi/Cellular readiness and measure round-trip latency against your chosen test endpoint.",
                            onManageClick = {
                                val intent = Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:${context.packageName}")
                                )
                                runCatching { context.startActivity(intent) }
                            }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        PermissionAuditRow(
                            name = "Tactile Haptics (VIBRATE)",
                            granted = integrityReport?.vibrateGranted == true,
                            explanation = "Install-time permission used strictly for subtle tactile feedback on sliders and buttons when enabled in Settings.",
                            onManageClick = null
                        )
                    }
                }
            }

            1 -> {
                // --- SUB-TAB 1: SETTINGS & PERSONALIZATION ---
                item {
                    CyberGlassCard(accentColor = NeonPurple) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Palette, contentDescription = null, tint = NeonPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "THEME & NEON ACCENT PALETTE",
                                style = MaterialTheme.typography.titleMedium,
                                color = NeonPurple,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("Theme Mode (Dark enabled by default):", style = MaterialTheme.typography.labelMedium)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(AppThemeMode.entries) { mode ->
                                FilterChip(
                                    selected = settings.themeModeId == mode.id,
                                    onClick = { onSelectThemeMode(mode.id) },
                                    label = { Text(mode.label) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Neon Accent Color:", style = MaterialTheme.typography.labelMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(AccentPalette.entries) { palette ->
                                val selected = settings.accentPaletteId == palette.id
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (selected) palette.primary.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (selected) 2.dp else 1.dp,
                                        color = palette.primary
                                    ),
                                    modifier = Modifier.clickable { onSelectAccentPalette(palette.id) }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(14.dp)
                                                .clip(CircleShape)
                                                .background(palette.primary)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(palette.label, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Interface Language:", style = MaterialTheme.typography.labelMedium)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(SUPPORTED_LANGUAGES) { (code, label) ->
                                FilterChip(
                                    selected = settings.languageCode == code,
                                    onClick = { onSelectLanguage(code) },
                                    label = { Text("$label (${code.uppercase()})") }
                                )
                            }
                        }
                    }
                }

                // Feedback, Animation Intensity & Interval
                item {
                    CyberGlassCard(accentColor = ElectricBlue) {
                        Text(
                            text = "INTERACTION & TELEMETRY TUNING",
                            style = MaterialTheme.typography.titleMedium,
                            color = ElectricBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Haptic Vibration Feedback", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = settings.hapticEnabled, onCheckedChange = onToggleHaptic)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("UI Sound Effects (Cyber Beeps)", style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = settings.soundEffectsEnabled, onCheckedChange = onToggleSound)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Animation & Glow Intensity", style = MaterialTheme.typography.bodyMedium)
                            Text("${(settings.animationIntensity * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
                        }
                        Slider(
                            value = settings.animationIntensity,
                            onValueChange = onChangeAnimationIntensity,
                            valueRange = 0f..1f,
                            colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = ElectricBlue)
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Default Telemetry Polling Interval:", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1000L to "1.0s", 1500L to "1.5s", 3000L to "3.0s", 5000L to "5.0s").forEach { (ms, label) ->
                                FilterChip(
                                    selected = settings.monitoringIntervalMs == ms,
                                    onClick = { onChangeMonitoringInterval(ms) },
                                    label = { Text(label) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    exportedSettingsJson = PresetJsonSerializer.exportSettingsToJson(
                                        settings = settings,
                                        sensitivityCount = sensitivityCount,
                                        crosshairCount = crosshairCount
                                    )
                                    showExportSettingsDialog = true
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Export Config")
                            }

                            OutlinedButton(
                                onClick = onResetSettings,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("reset_preferences_button")
                            ) {
                                Icon(Icons.Default.RestartAlt, contentDescription = null, tint = CyberCrimson, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Reset Defaults", color = CyberCrimson)
                            }
                        }
                    }
                }
            }

            2 -> {
                // --- SUB-TAB 2: MONETIZATION-READY ARCHITECTURE, PRIVACY & CAPABILITIES ---
                item {
                    CyberGlassCard(accentColor = NeonPurple, glowStrength = 0.65f) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = NeonPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "GHOST AURA PRO TIER & MONETIZATION",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = NeonPurple
                                )
                                Text(
                                    text = "Transparent Free vs. Pro feature comparison",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        TierComparisonRow("Sensitivity Reference Presets & JSON I/O", "Included", "Unlimited + Cloud Ready")
                        TierComparisonRow("12 Original Crosshair Reticle Styles", "Included", "Included + Custom Packs")
                        TierComparisonRow("Movable Floating Quick-Access HUD", "Included", "Included + Multi-Profile")
                        TierComparisonRow("Hardware & Network Latency Telemetry", "Included", "Extended History Export")
                        TierComparisonRow("Ad-Free Experience", "Standard", "Zero Ad Placements")

                        Spacer(modifier = Modifier.height(10.dp))

                        // Disabled Ad Placement Slots (Honest Monetization-Ready Architecture)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "ADS: UNITY LEVELPLAY (BANNER • INTERSTITIAL • REWARDED)",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = CyberAmber,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Ads are served by Unity LevelPlay. A banner shows above the navigation bar and an occasional interstitial appears between tabs. Ads stay off until the LevelPlay App Key and Ad Unit IDs are configured.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Optional Ad Consent Preference", style = MaterialTheme.typography.bodySmall)
                                    Switch(checked = settings.adPersonalizedConsent, onCheckedChange = onToggleAdConsent)
                                }
                            }
                        }
                    }
                }

                // Android API Capabilities & Limitations Matrix (Deliverable #12)
                item {
                    CyberGlassCard(accentColor = ElectricBlue) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = ElectricBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ANDROID API CAPABILITIES MATRIX",
                                style = MaterialTheme.typography.titleMedium,
                                color = ElectricBlue,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        AuditKeyValueRow("Total & Free RAM (ActivityManager)", "Supported (Live)")
                        AuditKeyValueRow("Battery % & Temp °C (BatteryManager)", "Supported (Hardware Sensor)")
                        AuditKeyValueRow("Internal Storage (StatFs)", "Supported (Live)")
                        AuditKeyValueRow("Display Resolution & Refresh Hz", "Supported (WindowManager)")
                        AuditKeyValueRow("Thermal Status (PowerManager)", "Supported on Android 10+")
                        AuditKeyValueRow("Authorized Endpoint Ping (HTTPS)", "Supported (On-Demand)")
                        AuditKeyValueRow("Floating Bubble & Reticle Overlay", "Supported (User Consent)")
                        AuditKeyValueRow("External Game Process FPS", "Limited by Android OS Sandbox")
                        AuditKeyValueRow("Hardware Cooling / Forced Overclock", "Limited by OS Kernel Security")
                    }
                }

                // Privacy & Security Policy Card
                item {
                    CyberGlassCard(accentColor = RestrainedGreen) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Policy, contentDescription = null, tint = RestrainedGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "PRIVACY POLICY & ABOUT",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = RestrainedGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Ghost Aura Gaming Utility Pro • Version 1.0.0",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            OutlinedButton(onClick = { showPrivacyModal = true }) {
                                Text("Read Policy", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• All sensitivity and crosshair presets are stored 100% locally on your device via Room & DataStore.\n• Zero game memory modification, zero file tampering, and zero credential collection.\n• Network access is used exclusively when you run an authorized endpoint latency check.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    if (showExportSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showExportSettingsDialog = false },
            title = { Text("Export App Settings JSON") },
            text = {
                OutlinedTextField(
                    value = exportedSettingsJson,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    textStyle = MaterialTheme.typography.labelSmall
                )
            },
            confirmButton = {
                Button(onClick = {
                    clipboard.setText(AnnotatedString(exportedSettingsJson))
                    showExportSettingsDialog = false
                }) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy JSON")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportSettingsDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showPrivacyModal) {
        AlertDialog(
            onDismissRequest = { showPrivacyModal = false },
            title = { Text("Privacy & Fair-Play Security Policy") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "1. Local-First Data Storage: Your sensitivity presets, custom crosshair reticles, and personalization preferences are stored locally on your device using Android Room and Jetpack DataStore. No personal data is uploaded to external servers.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "2. Fair Play & Anti-Cheat Compliance: Ghost Aura Gaming Utility Pro is a legitimate reference, diagnostic, and visual reticle utility. It never reads or modifies game memory, never injects code into other apps, and never automates touch input.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "3. Optional Overlay Transparency: The Display Over Other Apps permission is optional and only requested when you explicitly launch the floating quick-access bubble or reticle overlay. You can stop the overlay service at any time.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyModal = false }) {
                    Text("Understood")
                }
            }
        )
    }
}

@Composable
private fun AuditKeyValueRow(key: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = key, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PermissionAuditRow(
    name: String,
    granted: Boolean,
    explanation: String,
    onManageClick: (() -> Unit)?
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = if (granted) RestrainedGreen else CyberAmber,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurface)
            }
            if (onManageClick != null) {
                TextButton(onClick = onManageClick) {
                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (granted) "Manage" else "Grant", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Text(text = explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun TierComparisonRow(feature: String, freeTier: String, proTier: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = feature, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1.4f))
        Text(text = freeTier, style = MaterialTheme.typography.labelSmall, color = ElectricBlue, modifier = Modifier.weight(0.7f))
        Text(text = proTier, style = MaterialTheme.typography.labelSmall, color = NeonPurple, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
    }
}
