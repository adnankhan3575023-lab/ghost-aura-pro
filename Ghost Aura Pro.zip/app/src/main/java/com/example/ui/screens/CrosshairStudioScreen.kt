package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CrosshairPresetEntity
import com.example.data.CrosshairStyle
import com.example.ui.LiveCrosshairEditorState
import com.example.ui.components.CrosshairReticleCanvas
import com.example.ui.components.CyberGlassCard
import com.example.ui.components.SimulatedArenaPreviewBox
import com.example.ui.components.parseHexColorSafe
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RestrainedGreen
import java.util.Locale
import kotlin.math.roundToInt

private val RETICLE_COLOR_SWATCHES = listOf(
    "#00F0FF" to "Cyan",
    "#A855F7" to "Purple",
    "#10B981" to "Emerald",
    "#F43F5E" to "Crimson",
    "#FACC15" to "Yellow",
    "#FF6B00" to "Orange",
    "#38BDF8" to "Sky",
    "#EC4899" to "Pink",
    "#4ADE80" to "Neon Green",
    "#FFFFFF" to "Pure White"
)

@Composable
fun CrosshairStudioScreen(
    editorState: LiveCrosshairEditorState,
    savedPresets: List<CrosshairPresetEntity>,
    activeCrosshairId: Long,
    isReticleOverlayActive: Boolean,
    onUpdateEditor: ((LiveCrosshairEditorState) -> LiveCrosshairEditorState) -> Unit,
    onSavePreset: (String, Boolean) -> Unit,
    onSelectPreset: (CrosshairPresetEntity) -> Unit,
    onDuplicatePreset: (CrosshairPresetEntity) -> Unit,
    onDeletePreset: (CrosshairPresetEntity) -> Unit,
    onRestoreDefaults: () -> Unit,
    onToggleReticleOverlay: () -> Unit
) {
    var presetNameInput by remember(editorState.name) { mutableStateOf(editorState.name) }
    var customHexInput by remember(editorState.colorHex) { mutableStateOf(editorState.colorHex) }
    var renameTarget by remember { mutableStateOf<CrosshairPresetEntity?>(null) }
    var renameText by remember { mutableStateOf("") }

    val scenes = listOf("Tactical Range", "Cyber Grid", "Dusk Urban", "Daylight")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("crosshair_studio_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Simulated Arena Live Preview Card
        item {
            CyberGlassCard(accentColor = ElectricBlue, glowStrength = 0.6f) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "LIVE RETICLE STUDIO PREVIEW",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = CrosshairStyle.fromIndex(editorState.styleIndex).title,
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricBlue
                        )
                    }

                    OutlinedButton(
                        onClick = onToggleReticleOverlay,
                        modifier = Modifier.testTag("toggle_reticle_overlay_button")
                    ) {
                        Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isReticleOverlayActive) "Overlay: ON" else "Overlay: OFF",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isReticleOverlayActive) RestrainedGreen else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                SimulatedArenaPreviewBox(editorState = editorState)

                Spacer(modifier = Modifier.height(10.dp))

                // Background Scene & Moving Target Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LazyRow(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(scenes.indices.toList()) { idx ->
                            FilterChip(
                                selected = editorState.backgroundSceneIndex == idx,
                                onClick = {
                                    onUpdateEditor { it.copy(backgroundSceneIndex = idx) }
                                },
                                label = { Text(scenes[idx], style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = editorState.movingTargetDemo,
                        onClick = {
                            onUpdateEditor { it.copy(movingTargetDemo = !it.movingTargetDemo) }
                        },
                        label = { Text("Moving Bot", style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        // 2. 12 Original Reticle Styles Selector
        item {
            CyberGlassCard(accentColor = NeonPurple) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "12 ORIGINAL RETICLE STYLES",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Style #${editorState.styleIndex + 1}/12",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(CrosshairStyle.entries, key = { it.index }) { style ->
                        val selected = editorState.styleIndex == style.index
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) NeonPurple.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            border = androidx.compose.foundation.BorderStroke(
                                width = if (selected) 2.dp else 1.dp,
                                color = if (selected) NeonPurple else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier
                                .width(112.dp)
                                .clickable {
                                    onUpdateEditor { it.copy(styleIndex = style.index) }
                                }
                                .testTag("reticle_style_${style.index}")
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CrosshairReticleCanvas(
                                    styleIndex = style.index,
                                    sizeDp = 20f,
                                    thicknessDp = 2.0f,
                                    gapDp = 4f,
                                    showCenterDot = true,
                                    showOutline = true,
                                    colorHex = editorState.colorHex,
                                    opacity = 1f,
                                    rotationDeg = 0f,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = style.title,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Precision Geometry & Optical Controls
        item {
            CyberGlassCard(accentColor = ElectricBlue) {
                Text(
                    text = "GEOMETRY & OPTICAL CONTROLS",
                    style = MaterialTheme.typography.titleMedium,
                    color = ElectricBlue,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))

                ReticleSliderControl(
                    label = "Reticle Size",
                    valueText = "${editorState.sizeDp.roundToInt()} dp",
                    value = editorState.sizeDp,
                    range = 8f..64f,
                    color = ElectricBlue,
                    onValueChange = { v -> onUpdateEditor { it.copy(sizeDp = v) } }
                )

                ReticleSliderControl(
                    label = "Line Thickness",
                    valueText = String.format(Locale.US, "%.1f dp", editorState.thicknessDp),
                    value = editorState.thicknessDp,
                    range = 1f..8f,
                    color = NeonPurple,
                    onValueChange = { v -> onUpdateEditor { it.copy(thicknessDp = v) } }
                )

                ReticleSliderControl(
                    label = "Center Gap",
                    valueText = "${editorState.gapDp.roundToInt()} dp",
                    value = editorState.gapDp,
                    range = 0f..24f,
                    color = RestrainedGreen,
                    onValueChange = { v -> onUpdateEditor { it.copy(gapDp = v) } }
                )

                ReticleSliderControl(
                    label = "Opacity (Alpha)",
                    valueText = "${(editorState.opacity * 100).roundToInt()}%",
                    value = editorState.opacity,
                    range = 0.20f..1.0f,
                    color = ElectricBlue,
                    onValueChange = { v -> onUpdateEditor { it.copy(opacity = v) } }
                )

                ReticleSliderControl(
                    label = "Rotation Angle",
                    valueText = "${editorState.rotationDeg.roundToInt()}°",
                    value = editorState.rotationDeg,
                    range = 0f..360f,
                    color = NeonPurple,
                    onValueChange = { v -> onUpdateEditor { it.copy(rotationDeg = v) } }
                )

                // Quick Rotation Angle Snaps
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(0f, 45f, 90f, 180f).forEach { deg ->
                        FilterChip(
                            selected = editorState.rotationDeg.roundToInt() == deg.roundToInt(),
                            onClick = { onUpdateEditor { it.copy(rotationDeg = deg) } },
                            label = { Text("${deg.roundToInt()}°") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Center Dot Sight", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = editorState.showCenterDot,
                        onCheckedChange = { checked -> onUpdateEditor { it.copy(showCenterDot = checked) } },
                        modifier = Modifier.testTag("center_dot_switch")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("High-Contrast Shadow Outline", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = editorState.showOutline,
                        onCheckedChange = { checked -> onUpdateEditor { it.copy(showOutline = checked) } },
                        modifier = Modifier.testTag("outline_switch")
                    )
                }
            }
        }

        // 4. Color Swatches & Save Bar
        item {
            CyberGlassCard(accentColor = NeonPurple) {
                Text(
                    text = "NEON CHROMATIC PICKER",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonPurple,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(RETICLE_COLOR_SWATCHES) { (hex, label) ->
                        val c = parseHexColorSafe(hex)
                        val isSelected = editorState.colorHex.equals(hex, ignoreCase = true)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable {
                                customHexInput = hex
                                onUpdateEditor { it.copy(colorHex = hex) }
                            }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) Color.White else Color.Black.copy(alpha = 0.4f),
                                        shape = CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(label, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = customHexInput,
                        onValueChange = {
                            customHexInput = it.take(9)
                            if (it.startsWith("#") && (it.length == 7 || it.length == 9)) {
                                onUpdateEditor { state -> state.copy(colorHex = it) }
                            }
                        },
                        label = { Text("Hex (#RRGGBB)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = presetNameInput,
                        onValueChange = { presetNameInput = it.take(36) },
                        label = { Text("Reticle Preset Name") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1.3f)
                            .testTag("crosshair_name_input")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onSavePreset(presetNameInput, false) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_crosshair_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save")
                    }

                    OutlinedButton(
                        onClick = { onSavePreset("$presetNameInput #${savedPresets.size + 1}", true) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_new_crosshair_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save New")
                    }

                    OutlinedButton(
                        onClick = onRestoreDefaults,
                        modifier = Modifier.testTag("restore_default_crosshairs_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Restore defaults", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // 5. Saved Crosshair Presets List
        item {
            Text(
                text = "SAVED CROSSHAIR PRESETS (${savedPresets.size})",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        items(savedPresets, key = { it.id }) { preset ->
            val isActive = preset.id == activeCrosshairId
            CyberGlassCard(
                accentColor = if (isActive) RestrainedGreen else ElectricBlue,
                onClick = { onSelectPreset(preset) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        CrosshairReticleCanvas(
                            styleIndex = preset.styleIndex,
                            sizeDp = 22f,
                            thicknessDp = preset.thicknessDp,
                            gapDp = preset.gapDp.coerceAtMost(8f),
                            showCenterDot = preset.showCenterDot,
                            showOutline = preset.showOutline,
                            colorHex = preset.colorHex,
                            opacity = preset.opacity,
                            rotationDeg = preset.rotationDeg,
                            modifier = Modifier.size(52.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = preset.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${CrosshairStyle.fromIndex(preset.styleIndex).title} • ${preset.sizeDp.roundToInt()}dp",
                                style = MaterialTheme.typography.labelSmall,
                                color = ElectricBlue
                            )
                        }
                    }

                    Row {
                        IconButton(onClick = {
                            renameTarget = preset
                            renameText = preset.name
                        }) {
                            Icon(Icons.Default.Edit, contentDescription = "Rename", tint = ElectricBlue)
                        }
                        IconButton(onClick = { onDuplicatePreset(preset) }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = NeonPurple)
                        }
                        IconButton(onClick = { onDeletePreset(preset) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CyberCrimson)
                        }
                    }
                }
            }
        }
    }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Crosshair Preset") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it.take(36) },
                    label = { Text("Reticle Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (renameText.isNotBlank()) {
                        onSelectPreset(target.copy(name = renameText.trim()))
                        onSavePreset(renameText.trim(), false)
                    }
                    renameTarget = null
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ReticleSliderControl(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    color: Color,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium)
            Text(text = valueText, style = MaterialTheme.typography.labelLarge, color = color, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = color,
                activeTrackColor = color
            )
        )
    }
}
