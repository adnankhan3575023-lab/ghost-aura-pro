package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkPing
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.UserSettingsState
import com.example.monitoring.LatencyTestResult
import com.example.monitoring.ReadinessCheckItem
import com.example.monitoring.ReadinessLevel
import com.example.monitoring.TelemetrySnapshot
import com.example.ui.components.CyberGlassCard
import com.example.ui.components.TelemetryLineChart
import com.example.ui.components.parseHexColorSafe
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RestrainedGreen
import java.util.Locale
import kotlin.math.roundToInt

private val AUTHORIZED_PING_ENDPOINTS = listOf(
    "https://connectivitycheck.gstatic.com/generate_204" to "Google 204 Check",
    "https://1.1.1.1/cdn-cgi/trace" to "Cloudflare 1.1.1.1",
    "https://dns.google" to "Google Public DNS"
)

@Composable
fun PerformanceMonitorScreen(
    snapshot: TelemetrySnapshot,
    ramHistory: List<Float>,
    batteryTempHistory: List<Float>,
    framePacingHistory: List<Float>,
    readinessChecks: List<ReadinessCheckItem>,
    isPaused: Boolean,
    settings: UserSettingsState,
    latencyResult: LatencyTestResult?,
    isLatencyTesting: Boolean,
    inAppBubbleEnabled: Boolean,
    systemOverlayActive: Boolean,
    diagnosticReportBuilder: () -> String,
    onTogglePause: () -> Unit,
    onChangeInterval: (Long) -> Unit,
    onRunLatencyTest: (String) -> Unit,
    onUpdateBubbleAppearance: (Int, Float, String) -> Unit,
    onToggleInAppBubble: (Boolean) -> Unit,
    onRequestSystemOverlay: () -> Unit,
    onStopSystemOverlay: () -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var subTabIndex by remember { mutableIntStateOf(0) }
    val subTabs = listOf("Telemetry", "Readiness", "Floating HUD")

    var selectedEndpoint by remember { mutableStateOf(AUTHORIZED_PING_ENDPOINTS.first().first) }
    var showDiagnosticModal by remember { mutableStateOf(false) }
    var diagnosticJsonText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("performance_monitor_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Sub-navigation segmented row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                subTabs.forEachIndexed { idx, title ->
                    val selected = subTabIndex == idx
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { subTabIndex = idx }
                            .testTag("monitor_subtab_$idx")
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        when (subTabIndex) {
            0 -> {
                // --- SUB-TAB 0: LIVE TELEMETRY & HISTORICAL GRAPHS ---
                item {
                    CyberGlassCard(accentColor = ElectricBlue) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "SAMPLING ENGINE CONTROLS",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = ElectricBlue,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isPaused) "Status: Paused" else "Polling every ${settings.monitoringIntervalMs}ms",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = onTogglePause,
                                    modifier = Modifier.testTag("pause_resume_monitoring_button"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isPaused) RestrainedGreen else CyberAmber
                                    )
                                ) {
                                    Icon(
                                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (isPaused) "Resume" else "Pause")
                                }

                                OutlinedButton(
                                    onClick = {
                                        diagnosticJsonText = diagnosticReportBuilder()
                                        showDiagnosticModal = true
                                    },
                                    modifier = Modifier.testTag("export_diagnostics_button")
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = "Export report", modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Sampling Interval:", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1000L to "1.0s Fast", 1500L to "1.5s Balanced", 3000L to "3.0s Eco", 5000L to "5.0s Ultra-Eco").forEach { (ms, label) ->
                                FilterChip(
                                    selected = settings.monitoringIntervalMs == ms,
                                    onClick = { onChangeInterval(ms) },
                                    label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                }

                // Display Refresh Rate vs Game FPS Honesty Card
                item {
                    CyberGlassCard(accentColor = NeonPurple) {
                        Text(
                            text = "DISPLAY REFRESH RATE VS. GAME FPS",
                            style = MaterialTheme.typography.titleMedium,
                            color = NeonPurple,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Display Refresh Rate", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = snapshot.displayRefreshRateHz?.let { "${it.roundToInt()} Hz" } ?: "Not supported",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = ElectricBlue
                                )
                            }
                            Column {
                                Text("This App UI Pacing", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "${snapshot.localUiFramePacingFps.roundToInt()} FPS",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = RestrainedGreen
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("External Game FPS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "Not supported",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CyberAmber
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Supported Panel Modes: ${if (snapshot.supportedRefreshRatesHz.isNotEmpty()) snapshot.supportedRefreshRatesHz.joinToString("Hz, ") + "Hz" else "Standard"}. Android OS process isolation prevents unprivileged apps from reading another game's internal frame buffer.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        TelemetryLineChart(
                            dataPoints = framePacingHistory,
                            minValue = 0f,
                            maxValue = (snapshot.displayRefreshRateHz ?: 120f).coerceAtLeast(60f),
                            lineColor = NeonPurple,
                            unitSuffix = " FPS"
                        )
                    }
                }

                // Historical RAM Graph
                item {
                    CyberGlassCard(accentColor = ElectricBlue) {
                        Text(
                            text = "RAM UTILIZATION HISTORY (${snapshot.ramUsedMb} / ${snapshot.ramTotalMb} MB)",
                            style = MaterialTheme.typography.titleMedium,
                            color = ElectricBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        TelemetryLineChart(
                            dataPoints = ramHistory,
                            minValue = 0f,
                            maxValue = 100f,
                            lineColor = ElectricBlue,
                            unitSuffix = "%"
                        )
                    }
                }

                // Historical Battery Temperature Graph
                item {
                    CyberGlassCard(accentColor = RestrainedGreen) {
                        val tempNow = snapshot.batteryTempCelsius
                        Text(
                            text = if (tempNow != null) {
                                String.format(Locale.US, "BATTERY THERMAL HISTORY (%.1f°C • %s)", tempNow, snapshot.thermalStatusLabel)
                            } else {
                                "BATTERY THERMAL HISTORY (Not supported)"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = RestrainedGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        if (batteryTempHistory.isNotEmpty()) {
                            TelemetryLineChart(
                                dataPoints = batteryTempHistory,
                                minValue = 15f,
                                maxValue = 55f,
                                lineColor = RestrainedGreen,
                                unitSuffix = "°C"
                            )
                        } else {
                            Text(
                                text = "Not supported on this device's battery hardware interface.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Network Connectivity & Authorized Endpoint Latency Tester
                item {
                    CyberGlassCard(accentColor = NeonPurple) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NetworkPing, contentDescription = null, tint = ElectricBlue)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "AUTHORIZED NETWORK LATENCY TEST",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Transport: ${snapshot.networkTransportLabel} ${snapshot.networkDownstreamKbps?.let { "• ${it / 1000} Mbps Down" } ?: ""}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ElectricBlue
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(AUTHORIZED_PING_ENDPOINTS) { (url, name) ->
                                FilterChip(
                                    selected = selectedEndpoint == url,
                                    onClick = { selectedEndpoint = url },
                                    label = { Text(name, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = selectedEndpoint,
                            onValueChange = { selectedEndpoint = it.take(120) },
                            label = { Text("Authorized Test Endpoint (HTTPS)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("latency_endpoint_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { onRunLatencyTest(selectedEndpoint) },
                            enabled = !isLatencyTesting,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("run_latency_test_button")
                        ) {
                            Text(if (isLatencyTesting) "Measuring Round-Trip Latency..." else "Run Authorized Latency Test (4 Samples)")
                        }

                        latencyResult?.let { res ->
                            Spacer(modifier = Modifier.height(10.dp))
                            if (res.success) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    PingMetricColumn("AVG RTT", "${res.avgMs} ms", ElectricBlue)
                                    PingMetricColumn("MIN RTT", "${res.minMs} ms", RestrainedGreen)
                                    PingMetricColumn("MAX RTT", "${res.maxMs} ms", NeonPurple)
                                    PingMetricColumn("JITTER", "${res.jitterMs} ms", CyberAmber)
                                }
                            } else {
                                Text(
                                    text = "Test notice: ${res.errorMessage ?: "Unreachable"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberAmber
                                )
                            }
                        }
                    }
                }
            }

            1 -> {
                // --- SUB-TAB 1: DEVICE HEALTH & GAMING READINESS ---
                item {
                    val optimalCount = readinessChecks.count { it.status == ReadinessLevel.OPTIMAL }
                    val totalSupported = readinessChecks.count { it.status != ReadinessLevel.UNSUPPORTED }.coerceAtLeast(1)
                    val scorePct = ((optimalCount.toFloat() / totalSupported.toFloat()) * 100f).roundToInt()

                    CyberGlassCard(accentColor = RestrainedGreen, glowStrength = 0.6f) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "GAMING READINESS DIAGNOSTIC",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Informational hardware & environment check",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "$scorePct%",
                                style = MaterialTheme.typography.displayMedium,
                                color = if (scorePct >= 80) RestrainedGreen else CyberAmber
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = ElectricBlue.copy(alpha = 0.12f)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Transparency Notice: These diagnostics read real system states so you can prepare your device. Software utilities cannot physically cool hardware or override game engine FPS caps.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                items(readinessChecks, key = { it.title }) { item ->
                    val statusColor = when (item.status) {
                        ReadinessLevel.OPTIMAL -> RestrainedGreen
                        ReadinessLevel.CAUTION -> CyberAmber
                        ReadinessLevel.ATTENTION -> CyberCrimson
                        ReadinessLevel.UNSUPPORTED -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    CyberGlassCard(accentColor = statusColor) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (item.status == ReadinessLevel.OPTIMAL) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = item.status.label,
                                    tint = statusColor,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = statusColor.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = item.status.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = statusColor,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = item.currentValue,
                            style = MaterialTheme.typography.labelLarge,
                            color = ElectricBlue
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.recommendation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            2 -> {
                // --- SUB-TAB 2: FLOATING QUICK-ACCESS WIDGET STUDIO ---
                item {
                    CyberGlassCard(accentColor = NeonPurple, glowStrength = 0.6f) {
                        Text(
                            text = "FLOATING QUICK-ACCESS WIDGET",
                            style = MaterialTheme.typography.titleLarge,
                            color = NeonPurple
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Customize the movable utility bubble that provides instant access to your active sensitivity reference, crosshair reticle toggle, and live RAM/Battery telemetry.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Size Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Bubble Diameter", style = MaterialTheme.typography.bodyMedium)
                            Text("${settings.floatingBubbleSizeDp} dp", style = MaterialTheme.typography.labelLarge, color = NeonPurple)
                        }
                        Slider(
                            value = settings.floatingBubbleSizeDp.toFloat(),
                            onValueChange = {
                                onUpdateBubbleAppearance(
                                    it.roundToInt(),
                                    settings.floatingBubbleOpacity,
                                    settings.floatingBubbleColorHex
                                )
                            },
                            valueRange = 44f..76f,
                            colors = SliderDefaults.colors(thumbColor = NeonPurple, activeTrackColor = NeonPurple)
                        )

                        // Opacity Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Bubble Opacity", style = MaterialTheme.typography.bodyMedium)
                            Text("${(settings.floatingBubbleOpacity * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge, color = ElectricBlue)
                        }
                        Slider(
                            value = settings.floatingBubbleOpacity,
                            onValueChange = {
                                onUpdateBubbleAppearance(
                                    settings.floatingBubbleSizeDp,
                                    it,
                                    settings.floatingBubbleColorHex
                                )
                            },
                            valueRange = 0.35f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = ElectricBlue, activeTrackColor = ElectricBlue)
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Bubble Accent Glow:", style = MaterialTheme.typography.labelMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            listOf("#A855F7", "#00F0FF", "#10B981", "#F43F5E", "#FACC15").forEach { hex ->
                                val c = parseHexColorSafe(hex)
                                val selected = settings.floatingBubbleColorHex.equals(hex, ignoreCase = true)
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(c)
                                        .border(
                                            width = if (selected) 3.dp else 1.dp,
                                            color = if (selected) Color.White else Color.Transparent,
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            onUpdateBubbleAppearance(
                                                settings.floatingBubbleSizeDp,
                                                settings.floatingBubbleOpacity,
                                                hex
                                            )
                                        }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onToggleInAppBubble(!inAppBubbleEnabled) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (inAppBubbleEnabled) RestrainedGreen else MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Text(if (inAppBubbleEnabled) "Disable In-App Bubble" else "Enable In-App Bubble")
                            }

                            if (systemOverlayActive) {
                                OutlinedButton(
                                    onClick = onStopSystemOverlay,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Stop OS Overlay", color = CyberCrimson)
                                }
                            } else {
                                OutlinedButton(
                                    onClick = onRequestSystemOverlay,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Start OS Overlay")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDiagnosticModal) {
        AlertDialog(
            onDismissRequest = { showDiagnosticModal = false },
            title = { Text("Hardware Diagnostic Report") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = diagnosticJsonText,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp),
                        textStyle = MaterialTheme.typography.labelSmall
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(diagnosticJsonText))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy")
                        }
                        Button(
                            onClick = {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, diagnosticJsonText)
                                    putExtra(Intent.EXTRA_SUBJECT, "Ghost Aura Diagnostic Report")
                                }
                                context.startActivity(Intent.createChooser(send, "Export Diagnostic Report"))
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDiagnosticModal = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun PingMetricColumn(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.titleMedium, color = color, fontWeight = FontWeight.Bold)
    }
}
