package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ghost_aura_prefs")

data class UserSettingsState(
    val themeModeId: Int = 0, // 0 = Dark (default), 1 = Light, 2 = System
    val accentPaletteId: Int = 0, // 0 = Phantom Purple, 1 = Electric Blue, 2 = Restrained Green, 3 = Crimson
    val languageCode: String = "en",
    val hapticEnabled: Boolean = true,
    val soundEffectsEnabled: Boolean = true,
    val animationIntensity: Float = 1.0f, // 0.0f..1.0f
    val monitoringIntervalMs: Long = 1500L, // 1000L, 1500L, 3000L, 5000L
    val floatingBubbleSizeDp: Int = 56, // 44..76
    val floatingBubbleOpacity: Float = 0.92f, // 0.35f..1.0f
    val floatingBubbleColorHex: String = "#A855F7",
    val activeSensitivityId: Long = 1L,
    val activeCrosshairId: Long = 1L,
    val adPersonalizedConsent: Boolean = false,
    val adProviderConfigured: Boolean = false
)

class UserPreferencesRepository(private val context: Context) {
    private object Keys {
        val THEME_MODE = intPreferencesKey("theme_mode")
        val ACCENT_PALETTE = intPreferencesKey("accent_palette")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val ANIMATION_INTENSITY = floatPreferencesKey("animation_intensity")
        val MONITORING_INTERVAL = longPreferencesKey("monitoring_interval")
        val BUBBLE_SIZE = intPreferencesKey("bubble_size")
        val BUBBLE_OPACITY = floatPreferencesKey("bubble_opacity")
        val BUBBLE_COLOR = stringPreferencesKey("bubble_color")
        val ACTIVE_SENS_ID = longPreferencesKey("active_sens_id")
        val ACTIVE_CROSSHAIR_ID = longPreferencesKey("active_crosshair_id")
        val AD_CONSENT = booleanPreferencesKey("ad_consent")
    }

    val settingsFlow: Flow<UserSettingsState> = context.dataStore.data.map { prefs ->
        UserSettingsState(
            themeModeId = prefs[Keys.THEME_MODE] ?: 0,
            accentPaletteId = prefs[Keys.ACCENT_PALETTE] ?: 0,
            languageCode = prefs[Keys.LANGUAGE_CODE] ?: "en",
            hapticEnabled = prefs[Keys.HAPTIC_ENABLED] ?: true,
            soundEffectsEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            animationIntensity = prefs[Keys.ANIMATION_INTENSITY] ?: 1.0f,
            monitoringIntervalMs = prefs[Keys.MONITORING_INTERVAL] ?: 1500L,
            floatingBubbleSizeDp = prefs[Keys.BUBBLE_SIZE] ?: 56,
            floatingBubbleOpacity = prefs[Keys.BUBBLE_OPACITY] ?: 0.92f,
            floatingBubbleColorHex = prefs[Keys.BUBBLE_COLOR] ?: "#A855F7",
            activeSensitivityId = prefs[Keys.ACTIVE_SENS_ID] ?: 1L,
            activeCrosshairId = prefs[Keys.ACTIVE_CROSSHAIR_ID] ?: 1L,
            adPersonalizedConsent = prefs[Keys.AD_CONSENT] ?: false
        )
    }

    suspend fun updateThemeMode(modeId: Int) {
        context.dataStore.edit { it[Keys.THEME_MODE] = modeId }
    }

    suspend fun updateAccentPalette(paletteId: Int) {
        context.dataStore.edit { it[Keys.ACCENT_PALETTE] = paletteId }
    }

    suspend fun updateLanguage(code: String) {
        context.dataStore.edit { it[Keys.LANGUAGE_CODE] = code }
    }

    suspend fun updateHaptic(enabled: Boolean) {
        context.dataStore.edit { it[Keys.HAPTIC_ENABLED] = enabled }
    }

    suspend fun updateSoundEffects(enabled: Boolean) {
        context.dataStore.edit { it[Keys.SOUND_ENABLED] = enabled }
    }

    suspend fun updateAnimationIntensity(intensity: Float) {
        context.dataStore.edit { it[Keys.ANIMATION_INTENSITY] = intensity.coerceIn(0f, 1f) }
    }

    suspend fun updateMonitoringInterval(intervalMs: Long) {
        context.dataStore.edit { it[Keys.MONITORING_INTERVAL] = intervalMs.coerceIn(500L, 10000L) }
    }

    suspend fun updateFloatingBubbleConfig(sizeDp: Int, opacity: Float, colorHex: String) {
        context.dataStore.edit {
            it[Keys.BUBBLE_SIZE] = sizeDp.coerceIn(44, 80)
            it[Keys.BUBBLE_OPACITY] = opacity.coerceIn(0.3f, 1.0f)
            it[Keys.BUBBLE_COLOR] = colorHex
        }
    }

    suspend fun setActiveSensitivityPreset(id: Long) {
        context.dataStore.edit { it[Keys.ACTIVE_SENS_ID] = id }
    }

    suspend fun setActiveCrosshairPreset(id: Long) {
        context.dataStore.edit { it[Keys.ACTIVE_CROSSHAIR_ID] = id }
    }

    suspend fun updateAdConsent(consent: Boolean) {
        context.dataStore.edit { it[Keys.AD_CONSENT] = consent }
    }

    suspend fun resetAllSettings() {
        context.dataStore.edit { it.clear() }
    }
}
