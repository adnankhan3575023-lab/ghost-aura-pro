package com.example.data

import org.json.JSONArray
import org.json.JSONObject

object PresetJsonSerializer {

    fun exportSensitivityPresetsToJson(presets: List<SensitivityPresetEntity>): String {
        val root = JSONObject()
        root.put("schema", "ghost_aura_sensitivity_v1")
        root.put("disclaimer", "Reference values only for manual entry in Free Fire. Does not modify game files.")
        root.put("exportedAt", System.currentTimeMillis())
        val array = JSONArray()
        for (p in presets) {
            val obj = JSONObject().apply {
                put("name", p.name)
                put("category", p.category)
                put("general", p.general)
                put("redDot", p.redDot)
                put("scope2x", p.scope2x)
                put("scope4x", p.scope4x)
                put("sniperScope", p.sniperScope)
                put("freeLook", p.freeLook)
                put("deviceProfile", p.deviceProfile)
                put("screenSizeNotes", p.screenSizeNotes)
                put("refreshRateNotes", p.refreshRateNotes)
            }
            array.put(obj)
        }
        root.put("presets", array)
        return root.toString(2)
    }

    fun parseSensitivityPresetsFromJson(rawJson: String): Result<List<SensitivityPresetEntity>> {
        return runCatching {
            val trimmed = rawJson.trim()
            if (trimmed.isEmpty()) throw IllegalArgumentException("JSON input cannot be empty.")
            val array = if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                val root = JSONObject(trimmed)
                if (root.has("presets")) {
                    root.getJSONArray("presets")
                } else {
                    JSONArray().put(root)
                }
            }
            val parsed = mutableListOf<SensitivityPresetEntity>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val name = obj.optString("name", "Imported Preset ${i + 1}").take(40).ifBlank { "Imported Preset" }
                val category = obj.optString("category", "Custom").let {
                    if (it in listOf("High", "Medium", "Low", "Custom")) it else "Custom"
                }
                parsed.add(
                    SensitivityPresetEntity(
                        name = name,
                        category = category,
                        general = obj.optInt("general", 140).coerceIn(0, 200),
                        redDot = obj.optInt("redDot", 130).coerceIn(0, 200),
                        scope2x = obj.optInt("scope2x", 120).coerceIn(0, 200),
                        scope4x = obj.optInt("scope4x", 110).coerceIn(0, 200),
                        sniperScope = obj.optInt("sniperScope", 75).coerceIn(0, 200),
                        freeLook = obj.optInt("freeLook", 125).coerceIn(0, 200),
                        deviceProfile = obj.optString("deviceProfile", DeviceProfileOption.STANDARD_GAMING_PHONE.label),
                        screenSizeNotes = obj.optString("screenSizeNotes", "Imported user reference preset."),
                        refreshRateNotes = obj.optString("refreshRateNotes", "Manual configuration."),
                        isSample = false
                    )
                )
            }
            if (parsed.isEmpty()) throw IllegalArgumentException("No valid presets found in JSON.")
            parsed
        }
    }

    fun exportSettingsToJson(
        settings: UserSettingsState,
        sensitivityCount: Int,
        crosshairCount: Int
    ): String {
        return JSONObject().apply {
            put("app", "Ghost Aura Gaming Utility Pro")
            put("version", "1.0.0")
            put("themeModeId", settings.themeModeId)
            put("accentPaletteId", settings.accentPaletteId)
            put("languageCode", settings.languageCode)
            put("hapticEnabled", settings.hapticEnabled)
            put("soundEffectsEnabled", settings.soundEffectsEnabled)
            put("animationIntensity", settings.animationIntensity.toDouble())
            put("monitoringIntervalMs", settings.monitoringIntervalMs)
            put("floatingBubbleSizeDp", settings.floatingBubbleSizeDp)
            put("floatingBubbleOpacity", settings.floatingBubbleOpacity.toDouble())
            put("floatingBubbleColorHex", settings.floatingBubbleColorHex)
            put("savedSensitivityPresets", sensitivityCount)
            put("savedCrosshairPresets", crosshairCount)
        }.toString(2)
    }
}
