package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sensitivity_presets")
data class SensitivityPresetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val category: String, // "High", "Medium", "Low", "Custom"
    val general: Int, // 0..200 (Free Fire 1-200 scale)
    val redDot: Int, // 0..200
    val scope2x: Int, // 0..200
    val scope4x: Int, // 0..200
    val sniperScope: Int, // 0..200
    val freeLook: Int, // 0..200
    val deviceProfile: String,
    val screenSizeNotes: String,
    val refreshRateNotes: String,
    val isSample: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "crosshair_presets")
data class CrosshairPresetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val styleIndex: Int, // 0..11 (12 original styles)
    val sizeDp: Float, // 8f..64f
    val thicknessDp: Float, // 1f..8f
    val gapDp: Float, // 0f..24f
    val showCenterDot: Boolean,
    val showOutline: Boolean,
    val colorHex: String, // e.g., "#00F0FF"
    val opacity: Float, // 0.2f..1.0f
    val rotationDeg: Float, // 0f..360f
    val isDefault: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

enum class CrosshairStyle(val index: Int, val title: String, val subtitle: String) {
    CLASSIC_CROSS(0, "Classic Tactical Cross", "Four balanced orthogonal hairlines"),
    DOT_PRECISION(1, "Precision Dot + Cross", "Micro center point with spaced hairs"),
    CYBER_CHEVRON(2, "Cyber Chevron Apex", "Angular upward ballistic chevron"),
    CIRCLE_CORE(3, "Orbital Circle + Dot", "Clean ring reticle for shotgun & SMG spread"),
    BOX_BRACKET(4, "Tactical Box Bracket", "Corner framing brackets with open sightline"),
    DIAMOND_NEXUS(5, "Diamond Nexus", "45-degree rotated geometric lozenge"),
    SNIPER_T_POST(6, "Ballistic T-Post", "Open upper view with lower elevation marks"),
    DUAL_WING(7, "Dual Wing Stabilizer", "Horizontal tracking rails with center dot"),
    HEX_APOGEE(8, "Hexagonal Apogee", "Six-sided cybernetic precision frame"),
    TRI_BEAM(9, "Tri-Beam Predator", "120-degree radial vector convergence"),
    OCTA_RING(10, "Octa-Ring Radar", "Segmented compass reticle with tick marks"),
    GHOST_PULSE(11, "Ghost Aura Pulse", "Dual concentric cyber rings with cross ticks");

    companion object {
        fun fromIndex(index: Int): CrosshairStyle =
            entries.find { it.index == index } ?: CLASSIC_CROSS
    }
}

enum class DeviceProfileOption(
    val label: String,
    val defaultScreenNote: String,
    val defaultRefreshNote: String
) {
    COMPACT_PHONE(
        "Compact Phone (6.1\" - 6.4\")",
        "Shorter thumb sweep arc; slightly higher General & Red Dot reference helps fast 180° turns.",
        "Optimized for 60Hz - 90Hz touch sampling panels."
    ),
    STANDARD_GAMING_PHONE(
        "Large Phone (6.5\" - 6.8\")",
        "Balanced horizontal drag travel; ideal for medium-to-high 2x/4x drag control.",
        "Calibrated for 90Hz - 120Hz AMOLED displays."
    ),
    HIGH_HZ_FLAGSHIP(
        "Pro Flagship (120Hz - 165Hz)",
        "Ultra-low touch latency; moderated 4x & Sniper values prevent overshooting micro-adjustments.",
        "Designed for 120Hz/144Hz/165Hz high touch-sampling screens."
    ),
    TABLET_PAD(
        "Tablet / Pad (8.3\" - 11\"+)",
        "Wide physical swipe surface; lower-to-medium sensitivity provides steady multi-finger claw control.",
        "Suited for 60Hz - 120Hz large-format displays."
    )
}
