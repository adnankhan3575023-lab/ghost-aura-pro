package com.example.data

import kotlinx.coroutines.flow.Flow

class GhostAuraRepository(private val dao: GhostAuraDao) {
    val sensitivityPresets: Flow<List<SensitivityPresetEntity>> = dao.getAllSensitivityPresets()
    val crosshairPresets: Flow<List<CrosshairPresetEntity>> = dao.getAllCrosshairPresets()

    suspend fun ensureSeeded() {
        if (dao.getSensitivityCount() == 0) {
            dao.insertSensitivityPresets(defaultSensitivitySamples())
        }
        if (dao.getCrosshairCount() == 0) {
            dao.insertCrosshairPresets(defaultCrosshairSamples())
        }
    }

    suspend fun saveSensitivityPreset(preset: SensitivityPresetEntity): Long {
        return dao.insertSensitivityPreset(preset.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteSensitivityPreset(id: Long) {
        dao.deleteSensitivityPresetById(id)
    }

    suspend fun resetSensitivitySamples() {
        dao.deleteAllSensitivityPresets()
        dao.insertSensitivityPresets(defaultSensitivitySamples())
    }

    suspend fun saveCrosshairPreset(preset: CrosshairPresetEntity): Long {
        return dao.insertCrosshairPreset(preset.copy(updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteCrosshairPreset(id: Long) {
        dao.deleteCrosshairPresetById(id)
    }

    suspend fun resetCrosshairDefaults() {
        dao.deleteAllCrosshairPresets()
        dao.insertCrosshairPresets(defaultCrosshairSamples())
    }

    companion object {
        fun defaultSensitivitySamples(): List<SensitivityPresetEntity> {
            val now = System.currentTimeMillis()
            return listOf(
                SensitivityPresetEntity(
                    name = "Phantom Rush [High]",
                    category = "High",
                    general = 182,
                    redDot = 168,
                    scope2x = 156,
                    scope4x = 142,
                    sniperScope = 95,
                    freeLook = 160,
                    deviceProfile = DeviceProfileOption.COMPACT_PHONE.label,
                    screenSizeNotes = "Suggested for 6.1\"-6.5\" screens with compact thumb travel.",
                    refreshRateNotes = "Reference for 60Hz-90Hz displays needing brisk camera turns.",
                    isSample = true,
                    updatedAt = now
                ),
                SensitivityPresetEntity(
                    name = "Apex Balanced [Medium]",
                    category = "Medium",
                    general = 148,
                    redDot = 136,
                    scope2x = 128,
                    scope4x = 118,
                    sniperScope = 78,
                    freeLook = 130,
                    deviceProfile = DeviceProfileOption.STANDARD_GAMING_PHONE.label,
                    screenSizeNotes = "Balanced reference for 6.5\"-6.8\" all-rounder phones.",
                    refreshRateNotes = "Tuned for 90Hz-120Hz panels with smooth recoil pacing.",
                    isSample = true,
                    updatedAt = now - 1000
                ),
                SensitivityPresetEntity(
                    name = "Marksman Anchor [Low]",
                    category = "Low",
                    general = 112,
                    redDot = 104,
                    scope2x = 96,
                    scope4x = 88,
                    sniperScope = 62,
                    freeLook = 105,
                    deviceProfile = DeviceProfileOption.HIGH_HZ_FLAGSHIP.label,
                    screenSizeNotes = "Steady long-range tracking for high-sensitivity panels or tablets.",
                    refreshRateNotes = "120Hz-165Hz panels or 3/4-finger claw setups.",
                    isSample = true,
                    updatedAt = now - 2000
                ),
                SensitivityPresetEntity(
                    name = "Cyber Claw Hybrid [High]",
                    category = "High",
                    general = 174,
                    redDot = 158,
                    scope2x = 144,
                    scope4x = 132,
                    sniperScope = 84,
                    freeLook = 150,
                    deviceProfile = DeviceProfileOption.HIGH_HZ_FLAGSHIP.label,
                    screenSizeNotes = "Fast close-quarters flick reference with controlled 4x scope.",
                    refreshRateNotes = "120Hz AMOLED with high touch sampling enabled.",
                    isSample = true,
                    updatedAt = now - 3000
                )
            )
        }

        fun defaultCrosshairSamples(): List<CrosshairPresetEntity> {
            val now = System.currentTimeMillis()
            return listOf(
                CrosshairPresetEntity(
                    name = "Cyan Cyber Cross",
                    styleIndex = CrosshairStyle.DOT_PRECISION.index,
                    sizeDp = 24f,
                    thicknessDp = 2.2f,
                    gapDp = 5f,
                    showCenterDot = true,
                    showOutline = true,
                    colorHex = "#00F0FF",
                    opacity = 0.95f,
                    rotationDeg = 0f,
                    isDefault = true,
                    updatedAt = now
                ),
                CrosshairPresetEntity(
                    name = "Phantom Neon Chevron",
                    styleIndex = CrosshairStyle.CYBER_CHEVRON.index,
                    sizeDp = 26f,
                    thicknessDp = 2.5f,
                    gapDp = 4f,
                    showCenterDot = true,
                    showOutline = true,
                    colorHex = "#A855F7",
                    opacity = 0.92f,
                    rotationDeg = 0f,
                    isDefault = true,
                    updatedAt = now - 1000
                ),
                CrosshairPresetEntity(
                    name = "Emerald Orbital Ring",
                    styleIndex = CrosshairStyle.CIRCLE_CORE.index,
                    sizeDp = 28f,
                    thicknessDp = 2.0f,
                    gapDp = 6f,
                    showCenterDot = true,
                    showOutline = true,
                    colorHex = "#10B981",
                    opacity = 0.90f,
                    rotationDeg = 0f,
                    isDefault = true,
                    updatedAt = now - 2000
                ),
                CrosshairPresetEntity(
                    name = "Ghost Aura Pulse Core",
                    styleIndex = CrosshairStyle.GHOST_PULSE.index,
                    sizeDp = 30f,
                    thicknessDp = 2.0f,
                    gapDp = 5f,
                    showCenterDot = true,
                    showOutline = true,
                    colorHex = "#00F0FF",
                    opacity = 0.90f,
                    rotationDeg = 0f,
                    isDefault = true,
                    updatedAt = now - 3000
                )
            )
        }
    }
}
