package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GhostAuraDao {
    @Query("SELECT * FROM sensitivity_presets ORDER BY updatedAt DESC")
    fun getAllSensitivityPresets(): Flow<List<SensitivityPresetEntity>>

    @Query("SELECT COUNT(*) FROM sensitivity_presets")
    suspend fun getSensitivityCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSensitivityPreset(preset: SensitivityPresetEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSensitivityPresets(presets: List<SensitivityPresetEntity>)

    @Update
    suspend fun updateSensitivityPreset(preset: SensitivityPresetEntity)

    @Query("DELETE FROM sensitivity_presets WHERE id = :id")
    suspend fun deleteSensitivityPresetById(id: Long)

    @Query("DELETE FROM sensitivity_presets")
    suspend fun deleteAllSensitivityPresets()

    @Query("SELECT * FROM crosshair_presets ORDER BY updatedAt DESC")
    fun getAllCrosshairPresets(): Flow<List<CrosshairPresetEntity>>

    @Query("SELECT COUNT(*) FROM crosshair_presets")
    suspend fun getCrosshairCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCrosshairPreset(preset: CrosshairPresetEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCrosshairPresets(presets: List<CrosshairPresetEntity>)

    @Update
    suspend fun updateCrosshairPreset(preset: CrosshairPresetEntity)

    @Query("DELETE FROM crosshair_presets WHERE id = :id")
    suspend fun deleteCrosshairPresetById(id: Long)

    @Query("DELETE FROM crosshair_presets")
    suspend fun deleteAllCrosshairPresets()
}

@Database(
    entities = [SensitivityPresetEntity::class, CrosshairPresetEntity::class],
    version = 1,
    exportSchema = false
)
abstract class GhostAuraDatabase : RoomDatabase() {
    abstract fun dao(): GhostAuraDao

    companion object {
        @Volatile
        private var INSTANCE: GhostAuraDatabase? = null

        fun getInstance(context: Context): GhostAuraDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GhostAuraDatabase::class.java,
                    "ghost_aura_pro.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
