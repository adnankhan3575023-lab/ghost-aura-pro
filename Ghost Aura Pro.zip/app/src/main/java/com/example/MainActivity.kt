package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.GpsFixed
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ads.LevelPlayAdManager
import com.example.ads.LevelPlayBannerSlot
import com.example.ui.GhostAuraViewModel
import com.example.ui.components.InAppFloatingBubbleOverlay
import com.example.ui.screens.CrosshairStudioScreen
import com.example.ui.screens.CyberTerminalSettingsScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.PerformanceMonitorScreen
import com.example.ui.screens.SensitivityStudioScreen
import com.example.ui.theme.AccentPalette
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GhostAuraTheme
import com.example.ui.theme.RestrainedGreen
import kotlinx.coroutines.delay

private data class NavTabItem(
    val index: Int,
    val labelEn: String,
    val labelEs: String,
    val labelPt: String,
    val labelId: String,
    val labelHi: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    fun localizedLabel(lang: String): String = when (lang) {
        "es" -> labelEs
        "pt" -> labelPt
        "id" -> labelId
        "hi" -> labelHi
        else -> labelEn
    }
}

private val NAV_TABS = listOf(
    NavTabItem(0, "Dashboard", "Panel", "Painel", "Beranda", "डैशबोर्ड", Icons.Filled.Dashboard, Icons.Outlined.Dashboard, "nav_tab_dashboard"),
    NavTabItem(1, "Sensitivity", "Sensibilidad", "Sensibilidade", "Sensitivitas", "सेंसिटिविटी", Icons.Filled.Tune, Icons.Outlined.Tune, "nav_tab_sensitivity"),
    NavTabItem(2, "Crosshair", "Mira", "Mira", "Bidik", "क्रॉसहेयर", Icons.Filled.GpsFixed, Icons.Outlined.GpsFixed, "nav_tab_crosshair"),
    NavTabItem(3, "Monitor", "Monitor", "Monitor", "Monitor", "मॉनिटर", Icons.Filled.Speed, Icons.Outlined.Speed, "nav_tab_monitor"),
    NavTabItem(4, "Cyber Deck", "Cyber", "Cyber", "Siber", "साइबर", Icons.Filled.Security, Icons.Outlined.Security, "nav_tab_cyber")
)

class MainActivity : ComponentActivity() {

    private val viewModel: GhostAuraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        LevelPlayAdManager.init(this)
        setContent {
            val settings by viewModel.settingsState.collectAsStateWithLifecycle()
            val themeMode = AppThemeMode.fromId(settings.themeModeId)
            val accentPalette = AccentPalette.fromId(settings.accentPaletteId)

            GhostAuraTheme(
                themeMode = themeMode,
                accentPalette = accentPalette
            ) {
                GhostAuraMainApp(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshIntegrityReport()
        viewModel.sampleTelemetryNow()
    }
}

@Composable
fun GhostAuraMainApp(viewModel: GhostAuraViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settingsState.collectAsStateWithLifecycle()
    val snapshot by viewModel.telemetrySnapshot.collectAsStateWithLifecycle()
    val ramHistory by viewModel.ramHistory.collectAsStateWithLifecycle()
    val tempHistory by viewModel.batteryTempHistory.collectAsStateWithLifecycle()
    val frameHistory by viewModel.framePacingHistory.collectAsStateWithLifecycle()
    val readinessChecks by viewModel.readinessChecks.collectAsStateWithLifecycle()
    val isMonitoringPaused by viewModel.isMonitoringPaused.collectAsStateWithLifecycle()
    val latencyResult by viewModel.latencyTestResult.collectAsStateWithLifecycle()
    val isLatencyTesting by viewModel.isLatencyTesting.collectAsStateWithLifecycle()

    val sensitivityPresets by viewModel.sensitivityPresets.collectAsStateWithLifecycle()
    val crosshairPresets by viewModel.crosshairPresets.collectAsStateWithLifecycle()
    val crosshairEditor by viewModel.crosshairEditor.collectAsStateWithLifecycle()

    val inAppBubbleEnabled by viewModel.inAppFloatingPreviewEnabled.collectAsStateWithLifecycle()
    val systemOverlayActive by viewModel.systemOverlayActive.collectAsStateWithLifecycle()
    val crosshairOverlayActive by viewModel.crosshairOverlayActive.collectAsStateWithLifecycle()

    val terminalLogs by viewModel.terminalLogs.collectAsStateWithLifecycle()
    val isVisualDemoScanning by viewModel.isVisualDemoScanning.collectAsStateWithLifecycle()
    val visualDemoProgress by viewModel.visualDemoProgress.collectAsStateWithLifecycle()
    val integrityReport by viewModel.integrityReport.collectAsStateWithLifecycle()
    val bannerMessage by viewModel.statusBannerMessage.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableIntStateOf(0) }
    var showOverlayConsentDialog by remember { mutableStateOf(false) }
    var pendingReticleOverlayRequest by remember { mutableStateOf(false) }

    // System back button returns to Dashboard from any secondary tab
    BackHandler(enabled = currentTab != 0) {
        currentTab = 0
    }

    // Auto-clear status toast banner
    LaunchedEffect(bannerMessage) {
        if (bannerMessage != null) {
            delay(2800L)
            viewModel.clearBanner()
        }
    }

    val overlaySettingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshIntegrityReport()
        if (viewModel.canDrawSystemOverlays()) {
            viewModel.startOrUpdateSystemOverlay(showReticle = pendingReticleOverlayRequest)
        } else {
            viewModel.postBanner("Overlay permission not granted — using in-app floating preview instead.")
            viewModel.toggleInAppFloatingPreview(true)
        }
    }

    val handleRequestSystemOverlay: (Boolean) -> Unit = { requestReticle ->
        pendingReticleOverlayRequest = requestReticle
        if (systemOverlayActive && !requestReticle) {
            viewModel.stopSystemOverlay()
        } else if (viewModel.canDrawSystemOverlays()) {
            viewModel.startOrUpdateSystemOverlay(showReticle = requestReticle)
        } else {
            showOverlayConsentDialog = true
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
          Column {
            LevelPlayBannerSlot()
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                tonalElevation = 8.dp
            ) {
                NAV_TABS.forEach { tab ->
                    val selected = currentTab == tab.index
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            viewModel.triggerFeedback()
                            if (tab.index != currentTab) {
                                (context as? android.app.Activity)?.let { LevelPlayAdManager.onNaturalTransition(it) }
                            }
                            currentTab = tab.index
                        },
                        icon = {
                            Icon(
                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.labelEn
                            )
                        },
                        label = {
                            Text(
                                text = tab.localizedLabel(settings.languageCode),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
          }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.45f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "main_tab_transition"
            ) { targetTab ->
                when (targetTab) {
                    0 -> HomeDashboardScreen(
                        snapshot = snapshot,
                        ramHistory = ramHistory,
                        sensitivityPresets = sensitivityPresets,
                        crosshairPresets = crosshairPresets,
                        settings = settings,
                        inAppBubbleEnabled = inAppBubbleEnabled,
                        systemOverlayActive = systemOverlayActive,
                        onNavigateTab = { currentTab = it },
                        onToggleInAppBubble = { viewModel.toggleInAppFloatingPreview(it) },
                        onRequestSystemOverlay = { handleRequestSystemOverlay(false) },
                        onSelectSensitivity = { viewModel.selectActiveSensitivityPreset(it.id) },
                        onSelectCrosshair = { viewModel.loadCrosshairIntoEditor(it) },
                        onToggleDarkTheme = { isDark -> viewModel.setThemeMode(if (isDark) 0 else 1) },
                        onToggleHaptics = { viewModel.setHapticEnabled(it) }
                    )

                    1 -> SensitivityStudioScreen(
                        presets = sensitivityPresets,
                        activePresetId = settings.activeSensitivityId,
                        onSavePreset = { viewModel.saveSensitivityPreset(it) },
                        onDuplicatePreset = { viewModel.duplicateSensitivityPreset(it) },
                        onDeletePreset = { viewModel.deleteSensitivityPreset(it) },
                        onSelectActive = { viewModel.selectActiveSensitivityPreset(it) },
                        onResetSamples = { viewModel.resetSensitivitySamples() },
                        onImportJson = { raw, cb -> viewModel.importSensitivityJson(raw, cb) }
                    )

                    2 -> CrosshairStudioScreen(
                        editorState = crosshairEditor,
                        savedPresets = crosshairPresets,
                        activeCrosshairId = settings.activeCrosshairId,
                        isReticleOverlayActive = systemOverlayActive && crosshairOverlayActive,
                        onUpdateEditor = { viewModel.updateCrosshairEditor(it) },
                        onSavePreset = { name, asNew -> viewModel.saveCurrentCrosshairAsPreset(name, asNew) },
                        onSelectPreset = { viewModel.loadCrosshairIntoEditor(it) },
                        onDuplicatePreset = { viewModel.duplicateCrosshairPreset(it) },
                        onDeletePreset = { viewModel.deleteCrosshairPreset(it) },
                        onRestoreDefaults = { viewModel.restoreDefaultCrosshairs() },
                        onToggleReticleOverlay = {
                            if (systemOverlayActive && crosshairOverlayActive) {
                                viewModel.stopSystemOverlay()
                            } else {
                                handleRequestSystemOverlay(true)
                            }
                        }
                    )

                    3 -> PerformanceMonitorScreen(
                        snapshot = snapshot,
                        ramHistory = ramHistory,
                        batteryTempHistory = tempHistory,
                        framePacingHistory = frameHistory,
                        readinessChecks = readinessChecks,
                        isPaused = isMonitoringPaused,
                        settings = settings,
                        latencyResult = latencyResult,
                        isLatencyTesting = isLatencyTesting,
                        inAppBubbleEnabled = inAppBubbleEnabled,
                        systemOverlayActive = systemOverlayActive,
                        diagnosticReportBuilder = {
                            viewModel.telemetryMonitor.buildDiagnosticReportJson(
                                snapshot = snapshot,
                                historyRam = ramHistory,
                                lastLatency = latencyResult
                            )
                        },
                        onTogglePause = { viewModel.toggleMonitoringPaused() },
                        onChangeInterval = { viewModel.setMonitoringInterval(it) },
                        onRunLatencyTest = { viewModel.runLatencyCheck(it) },
                        onUpdateBubbleAppearance = { sz, op, hex ->
                            viewModel.updateBubbleAppearance(sz, op, hex)
                        },
                        onToggleInAppBubble = { viewModel.toggleInAppFloatingPreview(it) },
                        onRequestSystemOverlay = { handleRequestSystemOverlay(false) },
                        onStopSystemOverlay = { viewModel.stopSystemOverlay() }
                    )

                    4 -> CyberTerminalSettingsScreen(
                        terminalLogs = terminalLogs,
                        isVisualDemoScanning = isVisualDemoScanning,
                        visualDemoProgress = visualDemoProgress,
                        integrityReport = integrityReport,
                        settings = settings,
                        sensitivityCount = sensitivityPresets.size,
                        crosshairCount = crosshairPresets.size,
                        onRunVisualDemoSweep = { viewModel.runVisualDemoDiagnosticSweep() },
                        onRefreshIntegrity = { viewModel.refreshIntegrityReport() },
                        onSelectThemeMode = { viewModel.setThemeMode(it) },
                        onSelectAccentPalette = { viewModel.setAccentPalette(it) },
                        onSelectLanguage = { viewModel.setLanguage(it) },
                        onToggleHaptic = { viewModel.setHapticEnabled(it) },
                        onToggleSound = { viewModel.setSoundEffectsEnabled(it) },
                        onChangeAnimationIntensity = { viewModel.setAnimationIntensity(it) },
                        onChangeMonitoringInterval = { viewModel.setMonitoringInterval(it) },
                        onToggleAdConsent = { viewModel.setAdConsent(it) },
                        onResetSettings = { viewModel.resetAllPreferences() }
                    )
                }
            }

            // Movable In-App Floating Quick-Access Bubble
            if (inAppBubbleEnabled) {
                val activeSens = sensitivityPresets.find { it.id == settings.activeSensitivityId }
                    ?: sensitivityPresets.firstOrNull()
                InAppFloatingBubbleOverlay(
                    bubbleSizeDp = settings.floatingBubbleSizeDp,
                    bubbleOpacity = settings.floatingBubbleOpacity,
                    bubbleColorHex = settings.floatingBubbleColorHex,
                    telemetry = snapshot,
                    activeSensitivity = activeSens,
                    editorState = crosshairEditor,
                    onCloseBubble = { viewModel.toggleInAppFloatingPreview(false) },
                    onJumpToSensitivity = { currentTab = 1 },
                    onJumpToCrosshair = { currentTab = 2 }
                )
            }

            // Status Feedback Toast Banner
            AnimatedVisibility(
                visible = bannerMessage != null,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 14.dp, start = 16.dp, end = 16.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, RestrainedGreen),
                    shadowElevation = 8.dp,
                    modifier = Modifier.clickable { viewModel.clearBanner() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = bannerMessage ?: "",
                            style = MaterialTheme.typography.labelLarge,
                            color = ElectricBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    // Transparent Overlay Permission Explanation Dialog
    if (showOverlayConsentDialog) {
        AlertDialog(
            onDismissRequest = { showOverlayConsentDialog = false },
            title = { Text("Optional Overlay Permission") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(id = R.string.overlay_permission_rationale),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "You can also test the movable Floating Bubble right inside the app without granting system overlay permission.",
                        style = MaterialTheme.typography.labelSmall,
                        color = ElectricBlue
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showOverlayConsentDialog = false
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        runCatching { overlaySettingsLauncher.launch(intent) }
                            .onFailure {
                                viewModel.toggleInAppFloatingPreview(true)
                                viewModel.postBanner("Enabled In-App Floating Bubble")
                            }
                    }
                ) {
                    Text("Open Overlay Settings")
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            showOverlayConsentDialog = false
                            viewModel.toggleInAppFloatingPreview(true)
                            viewModel.postBanner("Enabled In-App Floating Bubble Preview")
                        }
                    ) {
                        Text("Use In-App Bubble")
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    TextButton(onClick = { showOverlayConsentDialog = false }) {
                        Text("Cancel")
                    }
                }
            }
        )
    }
}
