package com.example.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.monitoring.DeviceTelemetryMonitor
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Legitimate, user-controlled Android overlay service providing:
 * 1) Movable Floating Quick-Access Utility Bubble (expandable mini-panel with sensitivity reference,
 *    crosshair toggle, and real-time RAM/Battery info).
 * 2) Optional non-touchable visual Crosshair Overlay at the center of the screen.
 *
 * Security & Privacy compliance:
 * - Launches ONLY when explicitly started by the user and Settings.canDrawOverlays(context) is true.
 * - Never intercepts game controls (uses FLAG_NOT_FOCUSABLE, and FLAG_NOT_TOUCHABLE for the reticle).
 * - Never reads screen content or modifies any external app.
 * - Stops immediately when the user taps Close or disables the feature.
 */
class FloatingHudService : Service() {

    private var windowManager: WindowManager? = null
    private var bubbleRootView: LinearLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var expandedPanel: LinearLayout? = null
    private var telemetryTextView: TextView? = null
    private var sensitivityTextView: TextView? = null

    private var crosshairOverlayView: OverlayReticleView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null

    private lateinit var monitor: DeviceTelemetryMonitor
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isExpanded = false
    private var isReticleVisible = false

    // Configured values passed via Intent
    private var bubbleSizeDp: Int = 56
    private var bubbleAlpha: Float = 0.92f
    private var bubbleAccentHex: String = "#A855F7"
    private var presetSummary: String = "Gen: 148 | RedDot: 136 | 2x: 128 | 4x: 118"

    private var reticleStyleIndex: Int = 1
    private var reticleSizeDp: Float = 24f
    private var reticleThicknessDp: Float = 2.2f
    private var reticleGapDp: Float = 5f
    private var reticleCenterDot: Boolean = true
    private var reticleOutline: Boolean = true
    private var reticleColorHex: String = "#00F0FF"
    private var reticleOpacity: Float = 0.95f
    private var reticleRotationDeg: Float = 0f

    private val updateRunnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                val snap = monitor.sampleSnapshot()
                val tempStr = snap.batteryTempCelsius?.let { "${it.roundToInt()}°C" } ?: "N/A"
                val battStr = snap.batteryPercent?.let { "$it%" } ?: "N/A"
                val hzStr = snap.displayRefreshRateHz?.let { "${it.roundToInt()}Hz" } ?: "60Hz"
                telemetryTextView?.text = "RAM: ${snap.ramUsagePercent.roundToInt()}% (${snap.ramAvailableMb}MB Free)\nBATT: $battStr ($tempStr) • DISP: $hzStr"
                mainHandler.postDelayed(this, 2000L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        monitor = DeviceTelemetryMonitor(applicationContext)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_OVERLAY) {
            stopSelfCleanly()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelfCleanly()
            return START_NOT_STICKY
        }

        intent?.let {
            bubbleSizeDp = it.getIntExtra(EXTRA_BUBBLE_SIZE_DP, bubbleSizeDp)
            bubbleAlpha = it.getFloatExtra(EXTRA_BUBBLE_ALPHA, bubbleAlpha)
            bubbleAccentHex = it.getStringExtra(EXTRA_BUBBLE_COLOR) ?: bubbleAccentHex
            presetSummary = it.getStringExtra(EXTRA_PRESET_SUMMARY) ?: presetSummary
            isReticleVisible = it.getBooleanExtra(EXTRA_SHOW_RETICLE, isReticleVisible)

            reticleStyleIndex = it.getIntExtra(EXTRA_RETICLE_STYLE, reticleStyleIndex)
            reticleSizeDp = it.getFloatExtra(EXTRA_RETICLE_SIZE, reticleSizeDp)
            reticleThicknessDp = it.getFloatExtra(EXTRA_RETICLE_THICKNESS, reticleThicknessDp)
            reticleGapDp = it.getFloatExtra(EXTRA_RETICLE_GAP, reticleGapDp)
            reticleCenterDot = it.getBooleanExtra(EXTRA_RETICLE_DOT, reticleCenterDot)
            reticleOutline = it.getBooleanExtra(EXTRA_RETICLE_OUTLINE, reticleOutline)
            reticleColorHex = it.getStringExtra(EXTRA_RETICLE_COLOR) ?: reticleColorHex
            reticleOpacity = it.getFloatExtra(EXTRA_RETICLE_OPACITY, reticleOpacity)
            reticleRotationDeg = it.getFloatExtra(EXTRA_RETICLE_ROTATION, reticleRotationDeg)
        }

        startForegroundWithNotification()
        isRunning = true

        ensureBubbleOverlay()
        syncReticleOverlay()

        mainHandler.removeCallbacks(updateRunnable)
        mainHandler.post(updateRunnable)

        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val channelId = "ghost_aura_hud_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Ghost Aura Floating HUD",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active while the optional Ghost Aura floating utility bubble or reticle overlay is enabled."
            }
            nm.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingHudService::class.java).apply { action = ACTION_STOP_OVERLAY },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Ghost Aura HUD Active")
            .setContentText("Tap to return to app or stop the floating widget.")
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Overlay", stopIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun ensureBubbleOverlay() {
        val wm = windowManager ?: return
        val accentColor = runCatching { Color.parseColor(bubbleAccentHex) }.getOrDefault(Color.parseColor("#A855F7"))

        if (bubbleRootView != null) {
            sensitivityTextView?.text = presetSummary
            bubbleRootView?.alpha = bubbleAlpha
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpToPx(16f)
            y = dpToPx(180f)
        }
        bubbleParams = params

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            alpha = bubbleAlpha
        }

        // Circular Floating Bubble Handle
        val handleSizePx = dpToPx(bubbleSizeDp.toFloat())
        val bubbleHandle = TextView(this).apply {
            text = "GA"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E60F121C"))
                setStroke(dpToPx(2.5f), accentColor)
            }
            layoutParams = LinearLayout.LayoutParams(handleSizePx, handleSizePx)
        }

        // Collapsible Quick-Access HUD Panel
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dpToPx(12f), dpToPx(10f), dpToPx(12f), dpToPx(10f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(14f).toFloat()
                setColor(Color.parseColor("#F20A0C14"))
                setStroke(dpToPx(1.5f), accentColor)
            }
            val lp = LinearLayout.LayoutParams(dpToPx(240f), LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dpToPx(6f)
            layoutParams = lp
        }

        val headerTv = TextView(this).apply {
            text = "GHOST AURA QUICK HUD"
            setTextColor(accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
        }

        val telemetryTv = TextView(this).apply {
            text = "Sampling telemetry..."
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setPadding(0, dpToPx(4f), 0, dpToPx(4f))
        }
        telemetryTextView = telemetryTv

        val sensTv = TextView(this).apply {
            text = "REF: $presetSummary"
            setTextColor(Color.parseColor("#00F0FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setPadding(0, dpToPx(2f), 0, dpToPx(6f))
        }
        sensitivityTextView = sensTv

        val toggleCrosshairBtn = TextView(this).apply {
            text = if (isReticleVisible) "[HIDE RETICLE OVERLAY]" else "[SHOW RETICLE OVERLAY]"
            setTextColor(Color.parseColor("#10B981"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setPadding(0, dpToPx(4f), 0, dpToPx(4f))
            setOnClickListener {
                isReticleVisible = !isReticleVisible
                text = if (isReticleVisible) "[HIDE RETICLE OVERLAY]" else "[SHOW RETICLE OVERLAY]"
                syncReticleOverlay()
            }
        }

        val closeBtn = TextView(this).apply {
            text = "[CLOSE FLOATING HUD]"
            setTextColor(Color.parseColor("#F43F5E"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setPadding(0, dpToPx(4f), 0, dpToPx(2f))
            setOnClickListener {
                stopSelfCleanly()
            }
        }

        panel.addView(headerTv)
        panel.addView(telemetryTv)
        panel.addView(sensTv)
        panel.addView(toggleCrosshairBtn)
        panel.addView(closeBtn)
        expandedPanel = panel

        bubbleHandle.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = bubbleParams ?: return false
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = p.x
                        initialY = p.y
                        touchX = event.rawX
                        touchY = event.rawY
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - touchX).roundToInt()
                        val dy = (event.rawY - touchY).roundToInt()
                        if (abs(dx) > 8 || abs(dy) > 8) moved = true
                        p.x = initialX + dx
                        p.y = initialY + dy
                        runCatching { wm.updateViewLayout(root, p) }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            isExpanded = !isExpanded
                            expandedPanel?.visibility = if (isExpanded) View.VISIBLE else View.GONE
                        }
                        return true
                    }
                }
                return false
            }
        })

        root.addView(bubbleHandle)
        root.addView(panel)
        bubbleRootView = root

        runCatching { wm.addView(root, params) }
    }

    private fun syncReticleOverlay() {
        val wm = windowManager ?: return
        if (!isReticleVisible) {
            crosshairOverlayView?.let { view ->
                runCatching { wm.removeView(view) }
            }
            crosshairOverlayView = null
            return
        }

        if (crosshairOverlayView == null) {
            val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            val boxSizePx = dpToPx(120f)
            val params = WindowManager.LayoutParams(
                boxSizePx,
                boxSizePx,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.CENTER
            }
            crosshairParams = params
            val reticleView = OverlayReticleView(this)
            crosshairOverlayView = reticleView
            runCatching { wm.addView(reticleView, params) }
        }
        crosshairOverlayView?.invalidate()
    }

    private fun stopSelfCleanly() {
        isRunning = false
        mainHandler.removeCallbacks(updateRunnable)
        val wm = windowManager
        bubbleRootView?.let { view ->
            runCatching { wm?.removeView(view) }
        }
        bubbleRootView = null
        crosshairOverlayView?.let { view ->
            runCatching { wm?.removeView(view) }
        }
        crosshairOverlayView = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopSelfCleanly()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dpToPx(dp: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            resources.displayMetrics
        ).roundToInt()
    }

    private inner class OverlayReticleView(context: Context) : View(context) {
        private val mainPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val lenPx = dpToPx(reticleSizeDp / 2f).toFloat()
            val gapPx = dpToPx(reticleGapDp).toFloat()
            val thickPx = dpToPx(reticleThicknessDp).toFloat().coerceAtLeast(2f)

            val parsedColor = runCatching { Color.parseColor(reticleColorHex) }.getOrDefault(Color.CYAN)
            val alphaInt = (reticleOpacity.coerceIn(0.2f, 1f) * 255).roundToInt()

            mainPaint.color = parsedColor
            mainPaint.alpha = alphaInt
            mainPaint.strokeWidth = thickPx
            mainPaint.style = Paint.Style.STROKE
            mainPaint.strokeCap = Paint.Cap.ROUND

            outlinePaint.color = Color.BLACK
            outlinePaint.alpha = (alphaInt * 0.85f).roundToInt()
            outlinePaint.strokeWidth = thickPx + dpToPx(2f)
            outlinePaint.style = Paint.Style.STROKE
            outlinePaint.strokeCap = Paint.Cap.ROUND

            canvas.save()
            canvas.rotate(reticleRotationDeg, cx, cy)

            if (reticleOutline) {
                drawReticleGeometry(canvas, cx, cy, lenPx, gapPx, outlinePaint)
            }
            drawReticleGeometry(canvas, cx, cy, lenPx, gapPx, mainPaint)

            if (reticleCenterDot) {
                val dotRadius = (thickPx * 0.9f).coerceAtLeast(2.5f)
                if (reticleOutline) {
                    outlinePaint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, dotRadius + dpToPx(1f), outlinePaint)
                    outlinePaint.style = Paint.Style.STROKE
                }
                mainPaint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, dotRadius, mainPaint)
                mainPaint.style = Paint.Style.STROKE
            }

            canvas.restore()
        }

        private fun drawReticleGeometry(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            lenPx: Float,
            gapPx: Float,
            paint: Paint
        ) {
            when (reticleStyleIndex) {
                2 -> { // Cyber Chevron
                    canvas.drawLine(cx, cy - gapPx, cx - lenPx, cy + lenPx, paint)
                    canvas.drawLine(cx, cy - gapPx, cx + lenPx, cy + lenPx, paint)
                }
                3 -> { // Circle Core
                    canvas.drawCircle(cx, cy, (lenPx + gapPx).coerceAtLeast(6f), paint)
                }
                6 -> { // Ballistic T-Post
                    canvas.drawLine(cx - gapPx - lenPx, cy, cx - gapPx, cy, paint)
                    canvas.drawLine(cx + gapPx, cy, cx + gapPx + lenPx, cy, paint)
                    canvas.drawLine(cx, cy + gapPx, cx, cy + gapPx + lenPx, paint)
                }
                9 -> { // Tri-Beam
                    for (angle in listOf(-90.0, 30.0, 150.0)) {
                        val rad = Math.toRadians(angle)
                        val sx = cx + (gapPx * cos(rad)).toFloat()
                        val sy = cy + (gapPx * sin(rad)).toFloat()
                        val ex = cx + ((gapPx + lenPx) * cos(rad)).toFloat()
                        val ey = cy + ((gapPx + lenPx) * sin(rad)).toFloat()
                        canvas.drawLine(sx, sy, ex, ey, paint)
                    }
                }
                else -> { // 4-way cross & hybrid styles
                    canvas.drawLine(cx - gapPx - lenPx, cy, cx - gapPx, cy, paint)
                    canvas.drawLine(cx + gapPx, cy, cx + gapPx + lenPx, cy, paint)
                    canvas.drawLine(cx, cy - gapPx - lenPx, cx, cy - gapPx, paint)
                    canvas.drawLine(cx, cy + gapPx, cx, cy + gapPx + lenPx, paint)
                    if (reticleStyleIndex == 11) {
                        canvas.drawCircle(cx, cy, gapPx + lenPx * 0.65f, paint)
                    }
                }
            }
        }
    }

    companion object {
        private const val NOTIFICATION_ID = 4091
        const val ACTION_STOP_OVERLAY = "com.example.overlay.STOP_OVERLAY"

        const val EXTRA_BUBBLE_SIZE_DP = "extra_bubble_size_dp"
        const val EXTRA_BUBBLE_ALPHA = "extra_bubble_alpha"
        const val EXTRA_BUBBLE_COLOR = "extra_bubble_color"
        const val EXTRA_PRESET_SUMMARY = "extra_preset_summary"
        const val EXTRA_SHOW_RETICLE = "extra_show_reticle"

        const val EXTRA_RETICLE_STYLE = "extra_reticle_style"
        const val EXTRA_RETICLE_SIZE = "extra_reticle_size"
        const val EXTRA_RETICLE_THICKNESS = "extra_reticle_thickness"
        const val EXTRA_RETICLE_GAP = "extra_reticle_gap"
        const val EXTRA_RETICLE_DOT = "extra_reticle_dot"
        const val EXTRA_RETICLE_OUTLINE = "extra_reticle_outline"
        const val EXTRA_RETICLE_COLOR = "extra_reticle_color"
        const val EXTRA_RETICLE_OPACITY = "extra_reticle_opacity"
        const val EXTRA_RETICLE_ROTATION = "extra_reticle_rotation"

        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
