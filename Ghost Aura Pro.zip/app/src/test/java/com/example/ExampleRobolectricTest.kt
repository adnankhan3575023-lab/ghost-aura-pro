package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CrosshairStyle
import com.example.data.GhostAuraRepository
import com.example.data.PresetJsonSerializer
import com.example.monitoring.DeviceTelemetryMonitor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class ExampleRobolectricTest {

    @Test
    fun `verify app_name and core modules`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Ghost Aura Pro", appName)
    }

    @Test
    fun `verify 12 original crosshair styles and sample presets`() {
        assertEquals(12, CrosshairStyle.entries.size)
        val samples = GhostAuraRepository.defaultSensitivitySamples()
        assertTrue(samples.size >= 4)
        assertTrue(samples.all { it.isSample })
    }

    @Test
    fun `verify sensitivity preset json export and import roundtrip`() {
        val samples = GhostAuraRepository.defaultSensitivitySamples()
        val exportedJson = PresetJsonSerializer.exportSensitivityPresetsToJson(samples)
        assertTrue(exportedJson.contains("Phantom Rush [High]"))

        val parsedResult = PresetJsonSerializer.parseSensitivityPresetsFromJson(exportedJson)
        assertTrue(parsedResult.isSuccess)
        val imported = parsedResult.getOrThrow()
        assertEquals(samples.size, imported.size)
        assertEquals(samples.first().general, imported.first().general)

        val invalidResult = PresetJsonSerializer.parseSensitivityPresetsFromJson("{broken_json")
        assertFalse(invalidResult.isSuccess)
    }

    @Test
    fun `verify device telemetry monitor and readiness evaluation`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val monitor = DeviceTelemetryMonitor(context)
        val snapshot = monitor.sampleSnapshot()
        assertTrue(snapshot.ramTotalMb > 0L)
        val readiness = monitor.evaluateGamingReadiness(snapshot)
        assertEquals(5, readiness.size)
        val integrity = monitor.inspectAppIntegrity()
        assertTrue(integrity.packageName.isNotEmpty())
    }
}
